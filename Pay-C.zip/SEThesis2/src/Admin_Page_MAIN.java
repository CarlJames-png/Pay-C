import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class Admin_Page_MAIN extends JFrame {

    private JPanel contentPane;
    private JTable table;
    private DefaultTableModel tableModel;

    public static void main(String[] args) {
        // Apply FlatLaf Look and Feel
        SwingUtilities.invokeLater(() -> {
            try {
                new Admin_Page_MAIN().setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public Admin_Page_MAIN() {
        setTitle("Admin Dashboard");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 1000, 700);

        // Main Content Pane
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(15, 15, 15, 15));
        contentPane.setLayout(new BorderLayout(15, 15));
        setContentPane(contentPane);

        // Header Section
        JLabel lblTitle = new JLabel("Admin Dashboard - Manage Stalls");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 24));
        lblTitle.setForeground(new Color(41, 128, 185));
        lblTitle.setHorizontalAlignment(SwingConstants.CENTER);
        contentPane.add(lblTitle, BorderLayout.NORTH);
        
        // Log Out Button
        JLabel lblLogOut = new JLabel("LOG OUT");
        lblLogOut.setForeground(new Color(52, 152, 219));
        lblLogOut.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblLogOut.setBounds(20, 23, 80, 20);
        lblLogOut.setCursor(new Cursor(Cursor.HAND_CURSOR));
        contentPane.add(lblLogOut);

        lblLogOut.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent evt) {
                MainLogin.main(null);
                dispose();
            }
        });

        // Table Panel
        JPanel tablePanel = new JPanel(new BorderLayout());
        contentPane.add(tablePanel, BorderLayout.CENTER);

        // Table Model
        tableModel = new DefaultTableModel(new Object[]{"ID", "Stall Name", "Owner", "Location"}, 0);
        table = new JTable(tableModel);
        styleTable();

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(new LineBorder(new Color(41, 128, 185), 1, true));
        tablePanel.add(scrollPane, BorderLayout.CENTER);

        // Button Panel
        JPanel buttonsPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 15));
        contentPane.add(buttonsPanel, BorderLayout.SOUTH);

        JButton btnAdd = createButton("Add Stall", "icons/add.png", new Color(46, 204, 113));
        JButton btnEdit = createButton("Edit Stall", "icons/edit.png", new Color(241, 196, 15));
        JButton btnDelete = createButton("Delete Stall", "icons/delete.png", new Color(231, 76, 60));
        JButton btnViewDetails = createButton("View Details", "icons/details.png", new Color(52, 152, 219));
        JButton btnRefresh = createButton("Refresh", "icons/refresh.png", new Color(39, 174, 96));

        buttonsPanel.add(btnAdd);
        buttonsPanel.add(btnEdit);
        buttonsPanel.add(btnDelete);
        buttonsPanel.add(btnViewDetails);
        buttonsPanel.add(btnRefresh);

        // Load Stalls on Startup
        fetchAndDisplayStalls();

        // Button Actions
        btnAdd.addActionListener(e -> openStallDialog("Add Stall", null));
        btnEdit.addActionListener(e -> openEditStallDialog());
        btnDelete.addActionListener(e -> deleteSelectedStall());
        btnViewDetails.addActionListener(e -> {
            new RealTimeTransaction().setVisible(true);
            dispose();
        });
        btnRefresh.addActionListener(e -> fetchAndDisplayStalls());
    }

    private JButton createButton(String text, String iconPath, Color bgColor) {
        JButton button = new JButton(text, new ImageIcon(iconPath));
        button.setFont(new Font("Segoe UI", Font.BOLD, 14));
        button.setBackground(bgColor);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setPreferredSize(new Dimension(150, 40));
        button.setIconTextGap(10);
        return button;
    }

    private void styleTable() {
        table.setRowHeight(30);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 14));
        table.getTableHeader().setBackground(new Color(41, 128, 185));
        table.getTableHeader().setForeground(Color.WHITE);
        table.setSelectionBackground(new Color(41, 128, 185));
        table.setSelectionForeground(Color.WHITE);
        table.setGridColor(new Color(200, 200, 200));
    }

    private void fetchAndDisplayStalls() {
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/sethesis", "root", "");
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM stalls")) {

            tableModel.setRowCount(0); // Clear the table

            while (rs.next()) {
                tableModel.addRow(new Object[]{
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("owner"),
                        rs.getString("location")
                });
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error fetching stalls. Check database connection.", "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }

    private void handleStallSelection() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a stall first.", "Warning", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int stallId = (int) table.getValueAt(selectedRow, 0);
        String stallName = (String) table.getValueAt(selectedRow, 1);

        // Options Dialog
        Object[] options = {"View Orders", "View Products", "Cancel"};
        int choice = JOptionPane.showOptionDialog(
                this,
                "What would you like to do for Stall: " + stallName + "?",
                "Stall Options",
                JOptionPane.YES_NO_CANCEL_OPTION,
                JOptionPane.QUESTION_MESSAGE,
                null,
                options,
                options[0]
        );

        if (choice == JOptionPane.YES_OPTION) {
            openOrdersDialog(stallId, stallName);
        } else if (choice == JOptionPane.NO_OPTION) {
            openProductsDialog(stallId, stallName);
        }
    }

    private void openOrdersDialog(int id, String name) {
        // Sanitize and construct the table name
        String tableName = "orders_" + name.toLowerCase().replaceAll("[^a-zA-Z0-9_]", "_");

        JDialog dialog = new JDialog(this, "Orders for Stall: " + name, true);
        dialog.setSize(600, 400);
        dialog.setLayout(new BorderLayout());
        dialog.setLocationRelativeTo(this);

        DefaultTableModel ordersTableModel = new DefaultTableModel(new Object[]{"Order ID", "Product", "Quantity", "Price"}, 0);
        JTable ordersTable = new JTable(ordersTableModel);

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/sethesis", "root", "");
             Statement stmt = conn.createStatement()) {

            // Dynamically fetch the table for the selected stall
            String query = "SELECT * FROM `" + tableName + "`";
            ResultSet rs = stmt.executeQuery(query);

            while (rs.next()) {
                ordersTableModel.addRow(new Object[]{
                        rs.getInt("id"),
                        rs.getString("product_name"),
                        rs.getInt("quantity"),
                        rs.getDouble("price")
                });
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(
                    this,
                    "Error fetching orders for stall: " + name + ".\nDetails: " + e.getMessage(),
                    "Database Error",
                    JOptionPane.ERROR_MESSAGE
            );
            e.printStackTrace();
        }

        dialog.add(new JScrollPane(ordersTable), BorderLayout.CENTER);
        dialog.setVisible(true);
    }


    private void openProductsDialog(int stallId, String stallName) {
        JDialog dialog = new JDialog(this, "Products for Stall: " + stallName, true);
        dialog.setSize(600, 400);
        dialog.setLayout(new BorderLayout());
        dialog.setLocationRelativeTo(this);

        DefaultTableModel productsTableModel = new DefaultTableModel(new Object[]{"Product ID", "Product Name", "Price", "Stock"}, 0);
        JTable productsTable = new JTable(productsTableModel);

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/sethesis", "root", "");
             PreparedStatement stmt = conn.prepareStatement("SELECT * FROM products WHERE stall_id = ?")) {
            stmt.setInt(1, stallId);

            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                productsTableModel.addRow(new Object[]{
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getDouble("price"),
                        rs.getInt("stock")
                });
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error fetching products.", "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }

        dialog.add(new JScrollPane(productsTable), BorderLayout.CENTER);
        dialog.setVisible(true);
    }

    private void openEditStallDialog() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a stall to edit.", "Warning", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int id = (int) table.getValueAt(selectedRow, 0);
        String name = (String) table.getValueAt(selectedRow, 1);
        String owner = (String) table.getValueAt(selectedRow, 2);
        String location = (String) table.getValueAt(selectedRow, 3);

        Stall stall = new Stall(id, name, owner, location);
        openStallDialog("Edit Stall", stall);
    }


    private void deleteSelectedStall() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a stall to delete.", "Warning", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int stallId = (int) table.getValueAt(selectedRow, 0);

        int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete this stall?", "Confirm Delete", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/sethesis", "root", "");
                 PreparedStatement stmt = conn.prepareStatement("DELETE FROM stalls WHERE id = ?")) {
                stmt.setInt(1, stallId);
                stmt.executeUpdate();
                fetchAndDisplayStalls();
                JOptionPane.showMessageDialog(this, "Stall deleted successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, "Error deleting stall.", "Error", JOptionPane.ERROR_MESSAGE);
                e.printStackTrace();
            }
        }
    }


    private void openStallDialog(String title, Stall stall) {
        JDialog dialog = new JDialog(this, title, true);
        dialog.setSize(450, 300);
        dialog.setLayout(new BorderLayout(15, 15));
        dialog.setLocationRelativeTo(this);
        dialog.setResizable(false);

        // Header Section
        JLabel headerLabel = new JLabel(title, SwingConstants.CENTER);
        headerLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        headerLabel.setForeground(new Color(41, 128, 185));
        dialog.add(headerLabel, BorderLayout.NORTH);

        // Form Panel
        JPanel formPanel = new JPanel(new GridLayout(3, 2, 10, 10));
        formPanel.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));

        JLabel lblName = new JLabel("Stall Name:");
        lblName.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        JTextField txtName = new JTextField(stall != null ? stall.name : "");

        JLabel lblOwner = new JLabel("Owner:");
        lblOwner.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        JTextField txtOwner = new JTextField(stall != null ? stall.owner : "");

        JLabel lblLocation = new JLabel("Location:");
        lblLocation.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        JTextField txtLocation = new JTextField(stall != null ? stall.location : "");

        formPanel.add(lblName);
        formPanel.add(txtName);
        formPanel.add(lblOwner);
        formPanel.add(txtOwner);
        formPanel.add(lblLocation);
        formPanel.add(txtLocation);

        dialog.add(formPanel, BorderLayout.CENTER);

        // Button Panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 15, 10));
        JButton btnSave = createDialogButton("Save", new Color(46, 204, 113));
        JButton btnCancel = createDialogButton("Cancel", new Color(231, 76, 60));

        buttonPanel.add(btnCancel);
        buttonPanel.add(btnSave);

        dialog.add(buttonPanel, BorderLayout.SOUTH);

        // Button Actions
        btnSave.addActionListener(e -> {
            String name = txtName.getText().trim();
            String owner = txtOwner.getText().trim();
            String location = txtLocation.getText().trim();

            if (name.isEmpty() || owner.isEmpty() || location.isEmpty()) {
                JOptionPane.showMessageDialog(dialog, "All fields are required.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (stall == null) {
                // Add new stall
                try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/sethesis", "root", "");
                     PreparedStatement stmt = conn.prepareStatement("INSERT INTO stalls (name, owner, location) VALUES (?, ?, ?)")) {
                    stmt.setString(1, name);
                    stmt.setString(2, owner);
                    stmt.setString(3, location);
                    stmt.executeUpdate();
                    fetchAndDisplayStalls();
                    dialog.dispose();
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(dialog, "Error saving stall.", "Error", JOptionPane.ERROR_MESSAGE);
                    ex.printStackTrace();
                }
            } else {
                // Update existing stall
                try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/sethesis", "root", "");
                     PreparedStatement stmt = conn.prepareStatement("UPDATE stalls SET name = ?, owner = ?, location = ? WHERE id = ?")) {
                    stmt.setString(1, name);
                    stmt.setString(2, owner);
                    stmt.setString(3, location);
                    stmt.setInt(4, stall.id);
                    stmt.executeUpdate();
                    fetchAndDisplayStalls();
                    dialog.dispose();
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(dialog, "Error updating stall.", "Error", JOptionPane.ERROR_MESSAGE);
                    ex.printStackTrace();
                }
            }
        });

        btnCancel.addActionListener(e -> dialog.dispose());

        dialog.setVisible(true);
    }

    private JButton createDialogButton(String text, Color color) {
        JButton button = new JButton(text);
        button.setFont(new Font("Segoe UI", Font.BOLD, 14));
        button.setBackground(color);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setPreferredSize(new Dimension(100, 35));
        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.setBackground(color.brighter());
            }

            @Override
            public void mouseExited(MouseEvent e) {
                button.setBackground(color);
            }
        });
        return button;
    }

    
    static class Stall {
        int id;
        String name;
        String owner;
        String location;

        public Stall(int id, String name, String owner, String location) {
            this.id = id;
            this.name = name;
            this.owner = owner;
            this.location = location;
        }
    }
}
