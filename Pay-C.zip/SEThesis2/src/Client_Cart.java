import java.awt.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

public class Client_Cart extends JFrame {

    private JPanel contentPane;
    private DefaultListModel<String> cartModel;
    private JList<String> cartList;

    public Client_Cart() {
        setTitle("Shopping Cart");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setBounds(100, 100, 500, 400);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(10, 10, 10, 10));
        contentPane.setLayout(null);
        setContentPane(contentPane);

        // Initialize the cart model and list
        cartModel = new DefaultListModel<>();
        cartList = new JList<>(cartModel);
        JScrollPane scrollPane = new JScrollPane(cartList);
        scrollPane.setBounds(20, 20, 440, 200);
        contentPane.add(scrollPane);

        // Add a remove button
        JButton btnRemove = new JButton("Remove Selected");
        btnRemove.setBounds(20, 240, 200, 30);
        contentPane.add(btnRemove);

        // Add a checkout button
        JButton btnCheckout = new JButton("Checkout");
        btnCheckout.setBounds(260, 240, 200, 30);
        contentPane.add(btnCheckout);

        // Remove selected item from the cart
        btnRemove.addActionListener(e -> {
            String selectedItem = cartList.getSelectedValue();
            if (selectedItem != null) {
                cartModel.removeElement(selectedItem); // Remove from the model
            } else {
                JOptionPane.showMessageDialog(this, "No item selected.");
            }
        });

        // Checkout action
        btnCheckout.addActionListener(e -> {
            if (!cartModel.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Order placed successfully!");
                cartModel.clear(); // Clear the cart
            } else {
                JOptionPane.showMessageDialog(this, "Cart is empty.");
            }
        });
    }

    public void addItemToCart(String item) {
        cartModel.addElement(item);
    }

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                Client_Cart frame = new Client_Cart();
                frame.addItemToCart("Example Item 1");
                frame.addItemToCart("Example Item 2");
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }
}
