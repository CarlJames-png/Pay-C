import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class Client_Page_Main extends JFrame {

    private JPanel contentPane;
    private JTextField searchField;

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                Client_Page_Main frame = new Client_Page_Main();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public Client_Page_Main() {
        setTitle("Client Dashboard");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 1000, 700);
        contentPane = new JPanel();
        contentPane.setLayout(null);
        setContentPane(contentPane);

        setupFixedComponents();

        // Fetch stalls from the database and create panels dynamically
        List<Stall> stalls = fetchStallsFromDatabase();
        createStallPanels(stalls);
    }

    private void setupFixedComponents() {
        // Title Label
        JLabel lblTitle = new JLabel("Welcome to the PAY-C");
        lblTitle.setBounds(350, 10, 300, 30);
        lblTitle.setFont(new Font("Arial", Font.BOLD, 24));
        lblTitle.setHorizontalAlignment(SwingConstants.CENTER);
        contentPane.add(lblTitle);

        // Separator (Top)
        JSeparator topSeparator = new JSeparator();
        topSeparator.setBounds(10, 50, 960, 2);
        topSeparator.setForeground(Color.GRAY);
        contentPane.add(topSeparator);

        // Search Bar
        JLabel lblSearch = new JLabel("Search Stalls:");
        lblSearch.setFont(new Font("Arial", Font.PLAIN, 14));
        lblSearch.setBounds(220, 60, 120, 30);
        contentPane.add(lblSearch);

        searchField = new JTextField();
        searchField.setBounds(320, 60, 350, 30);
        contentPane.add(searchField);

        JButton btnSearch = new JButton("Search");
        btnSearch.setBounds(680, 60, 100, 30);
        btnSearch.setBackground(new Color(51, 153, 255));
        btnSearch.setForeground(Color.WHITE);
        btnSearch.setFont(new Font("Arial", Font.PLAIN, 14));
        contentPane.add(btnSearch);

        btnSearch.addActionListener(e -> {
            String query = searchField.getText().trim().toLowerCase();
            System.out.println("Search query: " + query); // Debugging print
            if (!query.isEmpty()) {
                List<Stall> filteredStalls = searchStalls(query);
                if (filteredStalls.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "No stalls found matching your search term.", "Search Results", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    updateStallPanels(filteredStalls);
                }
            } else {
                JOptionPane.showMessageDialog(this, "Please enter a search term.", "Search Error", JOptionPane.WARNING_MESSAGE);
            }
        });


        JButton btnShowAll = new JButton("Show All");
        btnShowAll.setBounds(790, 60, 100, 30);
        btnShowAll.setBackground(new Color(39, 174, 96));
        btnShowAll.setForeground(Color.WHITE);
        btnShowAll.setFont(new Font("Arial", Font.PLAIN, 14));
        contentPane.add(btnShowAll);

        btnShowAll.addActionListener(e -> {
            updateStallPanels(fetchStallsFromDatabase());
        });

        // Log Out Button
        JLabel lblLogOut = new JLabel("LOGOUT");
        lblLogOut.setForeground(new Color(52, 152, 219));
        lblLogOut.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblLogOut.setBounds(20, 23, 80, 20);
        lblLogOut.setCursor(new Cursor(Cursor.HAND_CURSOR));
        contentPane.add(lblLogOut);

        lblLogOut.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent evt) {
                MainLogin.main(null);
                dispose();
            }
        });
    }

    private void createStallPanels(List<Stall> stalls) {
        contentPane.removeAll();
        setupFixedComponents();

        int startX = 50;
        int startY = 120;
        int panelWidth = 200;
        int panelHeight = 220;
        int gapX = 30;
        int gapY = 30;

        for (int i = 0; i < stalls.size(); i++) {
            Stall stall = stalls.get(i);

            int x = startX + (i % 4) * (panelWidth + gapX);
            int y = startY + (i / 4) * (panelHeight + gapY);

            JPanel stallPanel = createStallPanel(stall, x, y);
            contentPane.add(stallPanel);
        }

        contentPane.revalidate();
        contentPane.repaint();
    }

    private JPanel createStallPanel(Stall stall, int x, int y) {
        JPanel stallPanel = new JPanel();
        stallPanel.setBounds(x, y, 200, 220);
        stallPanel.setLayout(null);
        stallPanel.setBorder(BorderFactory.createLineBorder(Color.BLACK));

        // Stall Image
        JLabel lblImage = new JLabel();
        lblImage.setBounds(10, 10, 180, 120);  // Image label size
        lblImage.setHorizontalAlignment(SwingConstants.CENTER);
        lblImage.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY));

        // Load and scale image
        try {
            ImageIcon originalImage = new ImageIcon(stall.getImagePath()); // Load the image
            Image img = originalImage.getImage(); // Get the image
            Image scaledImage = img.getScaledInstance(lblImage.getWidth(), lblImage.getHeight(), Image.SCALE_SMOOTH); // Scale it to fit the label
            lblImage.setIcon(new ImageIcon(scaledImage)); // Set the scaled image as the icon
        } catch (Exception e) {
            lblImage.setText("No Image");
            lblImage.setFont(new Font("Arial", Font.PLAIN, 14));
        }

        stallPanel.add(lblImage);

        // Stall Name
        JLabel lblName = new JLabel(stall.getName());
        lblName.setBounds(10, 140, 180, 20);
        lblName.setFont(new Font("Arial", Font.BOLD, 14));
        lblName.setHorizontalAlignment(SwingConstants.CENTER);
        stallPanel.add(lblName);

        // Description
        JLabel lblDesc = new JLabel(stall.getDescription());
        lblDesc.setBounds(10, 160, 180, 20);
        lblDesc.setFont(new Font("Arial", Font.PLAIN, 12));
        lblDesc.setHorizontalAlignment(SwingConstants.CENTER);
        stallPanel.add(lblDesc);

        // Location
        JLabel lblLocation = new JLabel("Location: " + stall.getLocation());
        lblLocation.setBounds(10, 180, 180, 20);
        lblLocation.setFont(new Font("Arial", Font.PLAIN, 12));
        lblLocation.setHorizontalAlignment(SwingConstants.CENTER);
        stallPanel.add(lblLocation);

        // Visit Button
        JButton btnVisit = new JButton("Visit");
        btnVisit.setBounds(60, 200, 80, 20);
        btnVisit.setBackground(new Color(51, 153, 255));
        btnVisit.setForeground(Color.WHITE);
        btnVisit.setFont(new Font("Arial", Font.PLAIN, 12));
        stallPanel.add(btnVisit);

        btnVisit.addActionListener(e -> openStallDetails(stall.getName()));

        return stallPanel;
    }

    private void openStallDetails(String stallName) {
        switch (stallName.toLowerCase()) {
            case "burger":
                EventQueue.invokeLater(() -> {
                    try {
                        Client_Page_BoomTasticBurger burgerPage = new Client_Page_BoomTasticBurger();
                        burgerPage.setVisible(true);
                        dispose();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                });
                break;
            case "cocolemon":
                EventQueue.invokeLater(() -> {
                    try {
                        Client_Page_CocoLemon cocolemonPage = new Client_Page_CocoLemon();
                        cocolemonPage.setVisible(true);
                        dispose();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                });
                break;
            case "turon":
                EventQueue.invokeLater(() -> {
                    try {
                        Client_Page_Turon turonPage = new Client_Page_Turon();
                        turonPage.setVisible(true);
                        dispose();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                });
                break;
            case "tindahan":
                EventQueue.invokeLater(() -> {
                    try {
                        Client_Page_Tindahan tindahanPage = new Client_Page_Tindahan();
                        tindahanPage.setVisible(true);
                        dispose();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                });
                break;
            case "shawarma":
                EventQueue.invokeLater(() -> {
                    try {
                        Client_Page_Xhiawarma shawarmaPage = new Client_Page_Xhiawarma();
                        shawarmaPage.setVisible(true);
                        dispose();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                });
                break;
            default:
                JOptionPane.showMessageDialog(this, "Page for " + stallName + " is under development!");
                break;
        }
    }

    private List<Stall> searchStalls(String query) {
        List<Stall> filteredStalls = new ArrayList<>();
        for (Stall stall : fetchStallsFromDatabase()) {
            if (stall.getName().toLowerCase().contains(query) ||
                stall.getDescription().toLowerCase().contains(query) ||
                stall.getLocation().toLowerCase().contains(query)) {
                filteredStalls.add(stall);
            }
        }
        return filteredStalls;
    }

    private void updateStallPanels(List<Stall> stalls) {
        contentPane.removeAll();
        setupFixedComponents();
        createStallPanels(stalls);
    }

    private List<Stall> fetchStallsFromDatabase() {
        List<Stall> stalls = new ArrayList<>();
        try (Connection conn = connectToDatabase();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM stalls")) {

            while (rs.next()) {
                String name = rs.getString("name");
                String description = rs.getString("description");
                String imagePath = rs.getString("image_path");
                String location = rs.getString("location");
                stalls.add(new Stall(name, description, imagePath, location));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return stalls;
    }

    private Connection connectToDatabase() throws SQLException {
        String url = "jdbc:mysql://localhost:3306/sethesis";
        String user = "root";
        String password = "";
        return DriverManager.getConnection(url, user, password);
    }

    static class Stall {
        private String name;
        private String description;
        private String imagePath;
        private String location;

        public Stall(String name, String description, String imagePath, String location) {
            this.name = name;
            this.description = description;
            this.imagePath = imagePath;
            this.location = location;
        }

        public String getName() {
            return name;
        }

        public String getDescription() {
            return description;
        }

        public String getImagePath() {
            return imagePath;
        }

        public String getLocation() {
            return location;
        }
    }
}
