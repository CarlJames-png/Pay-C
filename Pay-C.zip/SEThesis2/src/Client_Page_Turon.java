import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.io.File;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class Client_Page_Turon extends JFrame {

    private JPanel contentPane;
    private JTextField searchField;

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                Client_Page_Turon frame = new Client_Page_Turon();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public Client_Page_Turon() {
        setTitle("Client Dashboard");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 1000, 700);
        contentPane = new JPanel();
        contentPane.setLayout(null);
        setContentPane(contentPane);

        addHeaderAndSearchBar();

        // List of Stalls fetched from Database
        List<Stall> stalls = getStallsDataFromDatabase();

        displayStalls(stalls);
    }

    private void addHeaderAndSearchBar() {
        // Title Label
        JLabel lblTitle = new JLabel("Welcome to Saba Delights");
        lblTitle.setBounds(350, 10, 300, 30);
        lblTitle.setFont(new Font("Arial", Font.BOLD, 24));
        lblTitle.setHorizontalAlignment(SwingConstants.CENTER);
        contentPane.add(lblTitle);

        // Separator (Top)
        JSeparator topSeparator = new JSeparator();
        topSeparator.setBounds(10, 50, 960, 2);
        topSeparator.setForeground(Color.GRAY);
        contentPane.add(topSeparator);


        // Search Bar
        JLabel lblSearch = new JLabel("Search Product:");
        lblSearch.setFont(new Font("Arial", Font.PLAIN, 14));
        lblSearch.setBounds(220, 60, 120, 30);
        contentPane.add(lblSearch);
        
        // Log Out Button
        JLabel lblBack = new JLabel("<Back");
        lblBack.setForeground(new Color(52, 152, 219));
        lblBack.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblBack.setBounds(20, 20, 80, 20);
        lblBack.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        contentPane.add(lblBack);
        lblBack.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                Client_Page_Main.main(null);
                dispose();
            }
        });

        searchField = new JTextField();
        searchField.setBounds(320, 60, 350, 30);
        contentPane.add(searchField);

        JButton btnSearch = new JButton("Search");
        btnSearch.setBounds(680, 60, 100, 30);
        btnSearch.setBackground(new Color(51, 153, 255));
        btnSearch.setForeground(Color.WHITE);
        btnSearch.setFont(new Font("Arial", Font.PLAIN, 14));
        btnSearch.setBorder(BorderFactory.createLineBorder(new Color(51, 153, 255)));
        btnSearch.addActionListener(e -> {
            String query = searchField.getText().trim();

            if (query.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please enter a search term.", "Empty Search", JOptionPane.WARNING_MESSAGE);
                return;
            }

            List<Stall> filteredStalls = searchStalls(query);

            contentPane.removeAll();
            contentPane.revalidate();
            contentPane.repaint();

            addHeaderAndSearchBar();
            displayStalls(filteredStalls);

            if (filteredStalls.isEmpty()) {
                JOptionPane.showMessageDialog(this, "No results found for: \"" + query + "\"", "Search Results", JOptionPane.INFORMATION_MESSAGE);
            }
        });
        contentPane.add(btnSearch);

        JButton btnShowAll = new JButton("Show All Products");
        btnShowAll.setBounds(800, 60, 150, 30);
        btnShowAll.setBackground(new Color(51, 153, 255));
        btnShowAll.setForeground(Color.WHITE);
        btnShowAll.setFont(new Font("Arial", Font.PLAIN, 14));
        btnShowAll.setBorder(BorderFactory.createLineBorder(new Color(51, 153, 255)));
        btnShowAll.addActionListener(e -> {
            contentPane.removeAll();
            contentPane.revalidate();
            contentPane.repaint();

            addHeaderAndSearchBar();

            List<Stall> allStalls = getStallsDataFromDatabase();
            displayStalls(allStalls);
        });
        contentPane.add(btnShowAll);
    }

    private void displayStalls(List<Stall> stalls) {
        int startX = 50;
        int startY = 120;
        int panelWidth = 200;
        int panelHeight = 250;
        int gapX = 30;
        int gapY = 30;

        for (int i = 0; i < stalls.size(); i++) {
            int x = startX + (i % 4) * (panelWidth + gapX);
            int y = startY + (i / 4) * (panelHeight + gapY);

            Stall stall = stalls.get(i);
            JPanel stallPanel = createStallPanel(
                stall.getName(),
                stall.getDescription(),
                stall.getPrice(),
                stall.getWaitingTime(),  // Add waitingTime here
                x, y,
                stall.getImageFilePath()
            );
            contentPane.add(stallPanel);
        }

        contentPane.revalidate();
        contentPane.repaint();
    }

    private JPanel createStallPanel(String stallName, String description, double price, int waitingTime, int x, int y, String imageFileName) {
        JPanel stallPanel = new JPanel();
        stallPanel.setBounds(x, y, 200, 300); // Increase panel height to fit new content
        stallPanel.setLayout(null);
        stallPanel.setBorder(BorderFactory.createLineBorder(Color.BLACK));

        JLabel lblImage = new JLabel();
        lblImage.setBounds(10, 10, 180, 120);
        lblImage.setHorizontalAlignment(SwingConstants.CENTER);
        lblImage.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY));

        try {
            ImageIcon imageIcon;
            if (imageFileName != null && !imageFileName.isEmpty()) {
                File imageFile = new File(imageFileName);
                if (imageFile.exists()) {
                    // Load the image
                    imageIcon = new ImageIcon(imageFile.getAbsolutePath());
                } else {
                    System.err.println("Image not found: " + imageFileName);
                    imageIcon = new ImageIcon("C:\\Users\\Carl James Macapanas\\Desktop\\Pictures\\Tindahan\\Waffle.jpg"); // Fallback placeholder
                }
            } else {
                System.err.println("Image path is empty or null.");
                imageIcon = new ImageIcon("C:\\Users\\Carl James Macapanas\\Desktop\\Pictures\\Tindahan\\Waffle.jpg"); // Fallback placeholder
            }

            // Scale the image to fit into JLabel
            Image scaledImage = imageIcon.getImage().getScaledInstance(lblImage.getWidth(), lblImage.getHeight(), Image.SCALE_SMOOTH);
            lblImage.setIcon(new ImageIcon(scaledImage));
        } catch (Exception e) {
            System.err.println("Error loading image: " + e.getMessage());
            lblImage.setText("No Image");
            lblImage.setFont(new Font("Arial", Font.PLAIN, 14));
        }

        stallPanel.add(lblImage);

        JLabel lblName = new JLabel(stallName);
        lblName.setBounds(10, 140, 180, 20);
        lblName.setFont(new Font("Arial", Font.BOLD, 14));
        lblName.setHorizontalAlignment(SwingConstants.CENTER);
        stallPanel.add(lblName);

        JLabel lblDesc = new JLabel(description);
        lblDesc.setBounds(10, 160, 180, 20);
        lblDesc.setFont(new Font("Arial", Font.PLAIN, 12));
        lblDesc.setHorizontalAlignment(SwingConstants.CENTER);
        stallPanel.add(lblDesc);

        JLabel lblPrice = new JLabel("Price: $" + price);
        lblPrice.setBounds(10, 180, 180, 20);
        lblPrice.setFont(new Font("Arial", Font.PLAIN, 12));
        lblPrice.setHorizontalAlignment(SwingConstants.CENTER);
        stallPanel.add(lblPrice);

        JLabel lblWaitingTime = new JLabel("Waiting time: " + waitingTime + " mins");
        lblWaitingTime.setBounds(10, 200, 180, 20);
        lblWaitingTime.setFont(new Font("Arial", Font.PLAIN, 12));
        lblWaitingTime.setHorizontalAlignment(SwingConstants.CENTER);
        stallPanel.add(lblWaitingTime);

        JButton btnBuy = new JButton("Buy");
        btnBuy.setBounds(60, 230, 80, 30);
        btnBuy.setBackground(new Color(0, 123, 255));
        btnBuy.setForeground(Color.WHITE);
        btnBuy.setFont(new Font("Arial", Font.PLAIN, 14));
        btnBuy.addActionListener(e -> openOrderPage(stallName, price));
        stallPanel.add(btnBuy);

        return stallPanel;
    }



    private void openOrderPage(String stallName, double price) {
        // Main Frame
        JFrame orderFrame = new JFrame("Order - " + stallName);
        orderFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        orderFrame.setSize(350, 360);
        orderFrame.setLayout(null);
        orderFrame.setLocationRelativeTo(null);

        // Title Label
        JLabel lblTitle = new JLabel("Place Your Order");
        lblTitle.setBounds(10, 10, 330, 30);
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lblTitle.setHorizontalAlignment(SwingConstants.CENTER);
        orderFrame.add(lblTitle);

        // Customer Name Input
        JLabel lblCustomerName = new JLabel("Your Name:");
        lblCustomerName.setBounds(20, 50, 80, 20);
        lblCustomerName.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        orderFrame.add(lblCustomerName);

        JTextField txtCustomerName = new JTextField();
        txtCustomerName.setBounds(100, 50, 200, 25);
        txtCustomerName.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        orderFrame.add(txtCustomerName);

        // Product and Price Info
        JLabel lblStallName = new JLabel("Product: " + stallName);
        lblStallName.setBounds(20, 80, 310, 20);
        lblStallName.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        orderFrame.add(lblStallName);

        JLabel lblPrice = new JLabel("Price per unit: $" + String.format("%.2f", price));
        lblPrice.setBounds(20, 105, 310, 20);
        lblPrice.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        orderFrame.add(lblPrice);

        // Quantity Input
        JLabel lblQuantity = new JLabel("Quantity:");
        lblQuantity.setBounds(20, 135, 80, 25);
        lblQuantity.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        orderFrame.add(lblQuantity);

        JTextField txtQuantity = new JTextField();
        txtQuantity.setBounds(100, 135, 100, 25);
        txtQuantity.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        orderFrame.add(txtQuantity);

        // Total Display
        JLabel lblTotal = new JLabel("Total: $0.00");
        lblTotal.setBounds(20, 165, 310, 20);
        lblTotal.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblTotal.setForeground(new Color(34, 139, 34));
        orderFrame.add(lblTotal);

        // Payment Method Dropdown
        JLabel lblPaymentMethod = new JLabel("Payment:");
        lblPaymentMethod.setBounds(20, 195, 80, 25);
        lblPaymentMethod.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        orderFrame.add(lblPaymentMethod);

        JComboBox<String> paymentComboBox = new JComboBox<>(new String[]{"Cash", "Gcash"});
        paymentComboBox.setBounds(100, 195, 120, 25);
        paymentComboBox.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        orderFrame.add(paymentComboBox);

        // Load the barcode image
        String barcodePath = "C:\\Users\\Carl James Macapanas\\Desktop\\Pictures\\stalls\\QRCode.jpg"; // Path to the barcode image
        ImageIcon originalBarcodeIcon = new ImageIcon(barcodePath);

        // Scale the image to fit the JLabel dimensions (50x50)
        Image barcodeImage = originalBarcodeIcon.getImage();
        Image scaledBarcodeImage = barcodeImage.getScaledInstance(50, 50, Image.SCALE_SMOOTH);
        ImageIcon scaledBarcodeIcon = new ImageIcon(scaledBarcodeImage);

        // Barcode Image (Initially Hidden)
        JLabel barcodeLabel = new JLabel(scaledBarcodeIcon);

        // Position the barcode above the buttons
        int buttonY = 300; // Replace with the Y-coordinate of your first button
        int centerX = (orderFrame.getWidth() - 50) / 2; // Center X based on frame width

        barcodeLabel.setBounds(centerX, buttonY - 70, 50, 50); // Positioned above the buttons (e.g., 70px above)
        barcodeLabel.setHorizontalAlignment(SwingConstants.CENTER);
        barcodeLabel.setVisible(false);
        orderFrame.getContentPane().add(barcodeLabel);

        // Calculate and Place Order Buttons
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 15, 0)); // Centered with 15px spacing
        buttonPanel.setBounds(20, 290, 310, 35); // Positioned closer to content
        orderFrame.add(buttonPanel);

        JButton btnCalculate = new JButton("Calculate");
        btnCalculate.setPreferredSize(new Dimension(130, 30));
        btnCalculate.setBackground(new Color(30, 144, 255));
        btnCalculate.setForeground(Color.WHITE);
        btnCalculate.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        btnCalculate.addActionListener(e -> {
            try {
                int quantity = Integer.parseInt(txtQuantity.getText());
                if (quantity <= 0) {
                    JOptionPane.showMessageDialog(orderFrame, "Enter a valid quantity.", "Invalid Input", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                double total = price * quantity;
                lblTotal.setText("Total: $" + String.format("%.2f", total));
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(orderFrame, "Please enter a numeric quantity.", "Invalid Input", JOptionPane.ERROR_MESSAGE);
            }
        });
        buttonPanel.add(btnCalculate);

        JButton btnPlaceOrder = new JButton("Place Order");
        btnPlaceOrder.setPreferredSize(new Dimension(130, 30));
        btnPlaceOrder.setBackground(new Color(34, 139, 34));
        btnPlaceOrder.setForeground(Color.WHITE);
        btnPlaceOrder.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        btnPlaceOrder.addActionListener(e -> {
            try {
                int quantity = Integer.parseInt(txtQuantity.getText());
                String customerName = txtCustomerName.getText().trim();

                if (quantity <= 0) {
                    JOptionPane.showMessageDialog(orderFrame, "Enter a valid quantity.", "Invalid Input", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                if (customerName.isEmpty()) {
                    JOptionPane.showMessageDialog(orderFrame, "Please enter your name.", "Missing Information", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                double total = price * quantity;
                String paymentMethod = (String) paymentComboBox.getSelectedItem();

                if ("Gcash".equals(paymentMethod)) {
                    JOptionPane.showMessageDialog(orderFrame, "Scan the Gcash barcode to complete payment.");
                } else {
                    JOptionPane.showMessageDialog(orderFrame, "Order placed successfully with Cash!");
                }

                // Save the order details to the database
                saveOrderToDatabase(customerName, stallName + " x" + quantity, total, paymentMethod);
                orderFrame.dispose();
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(orderFrame, "Invalid quantity.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
        buttonPanel.add(btnPlaceOrder);

        // Show Barcode When Gcash Selected
        paymentComboBox.addActionListener(e -> {
            String selectedPayment = (String) paymentComboBox.getSelectedItem();
            barcodeLabel.setVisible("Gcash".equals(selectedPayment));
        });

        orderFrame.setVisible(true);
    }

    private void saveOrderToDatabase(String customerName, String orderDetails, double totalAmount, String paymentMethod) {
        String sql = "INSERT INTO orders_turon (customer_name, order_details, order_date, payment_method) VALUES (?, ?, CURRENT_TIMESTAMP, ?)";
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/sethesis", "root", "");
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, customerName);  // Add customer name
            pstmt.setString(2, orderDetails + " | Total: $" + String.format("%.2f", totalAmount));
            pstmt.setString(3, paymentMethod);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error saving order: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }



    private List<Stall> getStallsDataFromDatabase() {
        List<Stall> stalls = new ArrayList<>();

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/sethesis", "root", "");
             PreparedStatement stmt = conn.prepareStatement("SELECT * FROM stallturon");
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                String name = rs.getString("name");
                String description = rs.getString("description");
                double price = rs.getDouble("price");
                String imageFilePath = rs.getString("image_file_path");
                int waitingTime = rs.getInt("waiting_time"); // Fetch the waiting time
                stalls.add(new Stall(name, description, price, imageFilePath, waitingTime));
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error fetching data: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }

        return stalls;
    }


    private List<Stall> searchStalls(String query) {
        List<Stall> stalls = new ArrayList<>();
        String sql = "SELECT * FROM stallturon WHERE name LIKE ? OR description LIKE ?";

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/sethesis", "root", "");
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, "%" + query + "%");
            pstmt.setString(2, "%" + query + "%");

            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    String name = rs.getString("name");
                    String description = rs.getString("description");
                    double price = rs.getDouble("price");
                    String imageFilePath = rs.getString("image_file_path");
                    int waitingTime = rs.getInt("waiting_time");
                    stalls.add(new Stall(name, description, price, imageFilePath, waitingTime));
                }
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error fetching search results: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }

        return stalls;
    }

    static class Stall {
        private String name;
        private String description;
        private double price;
        private String imageFilePath;
        private int waitingTime; // Add waiting time field

        public Stall(String name, String description, double price, String imageFilePath, int waitingTime) {
            this.name = name;
            this.description = description;
            this.price = price;
            this.imageFilePath = imageFilePath;
            this.waitingTime = waitingTime;
        }

        public String getName() {
            return name;
        }

        public String getDescription() {
            return description;
        }

        public double getPrice() {
            return price;
        }

        public String getImageFilePath() {
            return imageFilePath;
        }

        public int getWaitingTime() {
            return waitingTime;
        }
    }

}

