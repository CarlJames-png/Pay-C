import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class LogIn_Admin extends JFrame {

    private JPanel contentPane;
    private JTextField txtUserName;
    private JPasswordField txtPassword;
    
    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                LogIn_Admin frame = new LogIn_Admin();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    /**
     * Create the frame.
     */
    public LogIn_Admin() {
        setTitle("PAY-C - Admin LogIn");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 600, 400);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(10, 10, 10, 10));
        contentPane.setBackground(new Color(245, 245, 245)); // Light gray background
        setContentPane(contentPane);
        contentPane.setLayout(null);

        // Title Label
        JLabel lblTitle = new JLabel("Admin Login");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 28));
        lblTitle.setHorizontalAlignment(SwingConstants.CENTER);
        lblTitle.setBounds(150, 10, 300, 40);
        contentPane.add(lblTitle);

        // Separator below the title
        JSeparator titleSeparator = new JSeparator();
        titleSeparator.setBounds(10, 58, 576, 2);
        titleSeparator.setForeground(Color.GRAY);
        contentPane.add(titleSeparator);

        // Picture/Logo Holder
        JLabel lblPicture = new JLabel("Picture Holder");
        lblPicture.setHorizontalAlignment(SwingConstants.CENTER);
        lblPicture.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        lblPicture.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY));
        lblPicture.setOpaque(true);
        lblPicture.setBackground(Color.WHITE);
        lblPicture.setBounds(20, 80, 200, 250);
        contentPane.add(lblPicture);

        // Load and display an image inside the picture holder
        String imagePath = "C:\\Users\\Carl James Macapanas\\Desktop\\Pictures\\stalls\\product1 (2).jpg"; // Replace with your image path
        ImageIcon originalIcon = new ImageIcon(imagePath);

        // Scale the image to fit the label's size (200x250)
        Image img = originalIcon.getImage(); // Get the image
        Image scaledImg = img.getScaledInstance(200, 250, Image.SCALE_SMOOTH); // Scale it to fit within the label

        // Set the scaled image to the label
        ImageIcon scaledIcon = new ImageIcon(scaledImg);
        lblPicture.setIcon(scaledIcon); // Set the icon to the JLabel


        // Username Label
        JLabel lblUserName = new JLabel("Username:");
        lblUserName.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblUserName.setBounds(250, 80, 100, 20);
        contentPane.add(lblUserName);

        // Username TextField
        txtUserName = new JTextField();
        txtUserName.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtUserName.setBounds(250, 100, 300, 30);
        txtUserName.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        contentPane.add(txtUserName);

        // Password Label
        JLabel lblPassword = new JLabel("Password:");
        lblPassword.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblPassword.setBounds(250, 140, 100, 20);
        contentPane.add(lblPassword);

        // Password Field
        txtPassword = new JPasswordField();
        txtPassword.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtPassword.setBounds(250, 160, 300, 30);
        txtPassword.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        contentPane.add(txtPassword);

        // Login Button
        JButton btnLogin = new JButton("Login");
        btnLogin.setFont(new Font("Segoe UI", Font.BOLD, 16));
        btnLogin.setBackground(new Color(39, 174, 96)); // Green
        btnLogin.setForeground(Color.WHITE);
        btnLogin.setFocusPainted(false);
        btnLogin.setBounds(332, 200, 140, 40);
        btnLogin.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnLogin.addActionListener(e -> validateLogin());
        contentPane.add(btnLogin);

        // Back JLabel (Clickable)
        JLabel lblBack = new JLabel("< Back");
        lblBack.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblBack.setForeground(new Color(52, 152, 219)); // Blue color
        lblBack.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        lblBack.setBounds(20, 20, 80, 20);
        lblBack.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                MainLogin.main(null);
                dispose(); // Close current frame
            }
        });
        contentPane.add(lblBack);

        // Footer
        JLabel lblFooter = new JLabel("© 2024 Market Management System - All Rights Reserved");
        lblFooter.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblFooter.setHorizontalAlignment(SwingConstants.CENTER);
        lblFooter.setBounds(10, 340, 576, 20);
        lblFooter.setForeground(Color.DARK_GRAY);
        contentPane.add(lblFooter);
    }

    /**
     * Validate the login credentials.
     */
    private void validateLogin() {
        String username = txtUserName.getText();
        String password = new String(txtPassword.getPassword());

        try {
            // Establish connection to MySQL database
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/sethesis", "root", "");

            // SQL query to check credentials
            String query = "SELECT * FROM adminLog WHERE username = ? AND password = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, username);
            stmt.setString(2, password);

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                JOptionPane.showMessageDialog(this, "Login Successful!", "Success", JOptionPane.INFORMATION_MESSAGE);
                Admin_Page_MAIN dashboard = new Admin_Page_MAIN();
                dashboard.setVisible(true);
                dispose(); // Close login window
            } else {
                JOptionPane.showMessageDialog(this, "Invalid Username or Password!", "Login Failed", JOptionPane.ERROR_MESSAGE);
            }

            // Close resources
            rs.close();
            stmt.close();
            conn.close();

        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Database Connection Failed: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }


}
