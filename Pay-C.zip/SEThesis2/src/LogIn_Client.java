import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class LogIn_Client extends JFrame {

    private JPanel contentPane;
    private JTextField txtUsername;
    private JPasswordField txtPassword;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                LogIn_Client frame = new LogIn_Client();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    /**
     * Create the frame.
     */
    public LogIn_Client() {
        setTitle("PAY-C - Client LogIn ");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 600, 400);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(10, 10, 10, 10));
        contentPane.setBackground(new Color(245, 245, 245)); // Light gray background
        setContentPane(contentPane);
        contentPane.setLayout(null);

        // Title Label
        JLabel lblTitle = new JLabel("Customer Login");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 28));
        lblTitle.setHorizontalAlignment(SwingConstants.CENTER);
        lblTitle.setBounds(150, 10, 300, 40);
        contentPane.add(lblTitle);

        // Separator below the title
        JSeparator titleSeparator = new JSeparator();
        titleSeparator.setBounds(10, 58, 576, 2);
        titleSeparator.setForeground(Color.GRAY);
        contentPane.add(titleSeparator);

        // Picture/Logo Holder
        String imagePath = "C:\\Users\\Carl James Macapanas\\Desktop\\Pictures\\stalls\\product1 (4).jpg"; // Replace with the actual image path

        // Create a JLabel to act as the picture holder
        JLabel lblPicture = new JLabel();

        // Load the image and scale it to fit the desired area
        ImageIcon originalIcon = new ImageIcon(imagePath);  // Load the image
        Image img = originalIcon.getImage();  // Get the Image from the Icon
        Image scaledImg = img.getScaledInstance(200, 250, Image.SCALE_SMOOTH);  // Resize image to fit 200x250
        ImageIcon scaledIcon = new ImageIcon(scaledImg);  // Create an ImageIcon from the scaled image

        lblPicture.setIcon(scaledIcon);  // Set the scaled icon to the label
        lblPicture.setHorizontalAlignment(SwingConstants.CENTER);  // Center align the image
        lblPicture.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY));  // Add a light gray border
        lblPicture.setOpaque(true);  // Make the label opaque to set background color
        lblPicture.setBackground(Color.WHITE);  // Set a white background
        lblPicture.setBounds(20, 80, 200, 250);  // Set the size and position of the label
        contentPane.add(lblPicture);  // Add the label to the content pane


        // Username Label
        JLabel lblUsername = new JLabel("Username:");
        lblUsername.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblUsername.setBounds(250, 80, 100, 20);
        contentPane.add(lblUsername);

        // Username TextField
        txtUsername = new JTextField();
        txtUsername.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtUsername.setBounds(250, 100, 300, 30);
        txtUsername.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        contentPane.add(txtUsername);

        // Password Label
        JLabel lblPassword = new JLabel("Password:");
        lblPassword.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblPassword.setBounds(250, 140, 100, 20);
        contentPane.add(lblPassword);

        // Password Field
        txtPassword = new JPasswordField();
        txtPassword.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtPassword.setBounds(250, 160, 300, 30);
        txtPassword.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        contentPane.add(txtPassword);

        // Login Button
        JButton btnLogin = new JButton("Login");
        btnLogin.setFont(new Font("Segoe UI", Font.BOLD, 16));
        btnLogin.setBackground(new Color(39, 174, 96)); // Green
        btnLogin.setForeground(Color.WHITE);
        btnLogin.setFocusPainted(false);
        btnLogin.setBounds(332, 200, 140, 40);
        btnLogin.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnLogin.addActionListener(e -> validateLogin());
        contentPane.add(btnLogin);

        // Back JLabel (Clickable)
        JLabel lblBack = new JLabel("< Back");
        lblBack.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblBack.setForeground(new Color(52, 152, 219)); // Blue color
        lblBack.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        lblBack.setBounds(20, 20, 80, 20);
        lblBack.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                MainLogin.main(null);
                dispose();
            }

            @Override
            public void mouseEntered(MouseEvent e) {
                lblBack.setForeground(new Color(41, 128, 185)); // Darker blue on hover
            }

            @Override
            public void mouseExited(MouseEvent e) {
                lblBack.setForeground(new Color(52, 152, 219)); // Reset to original color
            }
        });
        contentPane.add(lblBack);

        // Sign Up JLabel (Clickable)
        JLabel lblSignUp = new JLabel("Sign Up");
        lblSignUp.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblSignUp.setForeground(new Color(52, 152, 219)); // Blue color
        lblSignUp.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        lblSignUp.setBounds(379, 264, 55, 20);
        lblSignUp.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                SignUp_Client.main(null);
                dispose();
            }

            @Override
            public void mouseEntered(MouseEvent e) {
                lblSignUp.setForeground(new Color(41, 128, 185)); // Darker blue on hover
            }

            @Override
            public void mouseExited(MouseEvent e) {
                lblSignUp.setForeground(new Color(52, 152, 219)); // Reset to original color
            }
        });
        contentPane.add(lblSignUp);

        // Footer
        JLabel lblFooter = new JLabel("© 2024 Market Management System - All Rights Reserved");
        lblFooter.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblFooter.setHorizontalAlignment(SwingConstants.CENTER);
        lblFooter.setBounds(10, 340, 576, 20);
        lblFooter.setForeground(Color.DARK_GRAY);
        contentPane.add(lblFooter);
        
        JLabel lblNewLabel = new JLabel("Already have an account? ");
        lblNewLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblNewLabel.setBounds(323, 238, 181, 30);
        contentPane.add(lblNewLabel);
    }

    /**
     * Validate the login credentials.
     */
    private void validateLogin() {
        String username = txtUsername.getText();
        String password = new String(txtPassword.getPassword());

        try {
            // Establish connection to MySQL database
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/sethesis", "root", "");

            // SQL query to check credentials
            String query = "SELECT * FROM clientlog WHERE username = ? AND password = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, username);
            stmt.setString(2, password);

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                JOptionPane.showMessageDialog(this, "Login Successful!", "Success", JOptionPane.INFORMATION_MESSAGE);
                Client_Page_Main dashboard = new Client_Page_Main();
                dashboard.setVisible(true);
                this.dispose(); // Close login window
            } else {
                JOptionPane.showMessageDialog(this, "Invalid Username or Password!", "Login Failed", JOptionPane.ERROR_MESSAGE);
            }

            // Close resources
            rs.close();
            stmt.close();
            conn.close();

        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Database Connection Failed: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
