import java.awt.*;
import java.awt.event.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;

public class LogIn_MAIN extends JFrame {

    private JPanel contentPane;
    private JLabel lblNewLabel; // JLabel for displaying the image
    private JLabel lblTime; // JLabel for displaying the time

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                LogIn_MAIN frame = new LogIn_MAIN();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    /**
     * Create the frame.
     */
    public LogIn_MAIN() {
        setTitle("Market Management System - Log In");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 800, 600);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(10, 10, 10, 10));
        contentPane.setBackground(new Color(245, 245, 245)); // Subtle background color
        setContentPane(contentPane);
        contentPane.setLayout(null);

        // Title Label
        JLabel lblTitle = new JLabel("Welcome to Market Management");
        lblTitle.setHorizontalAlignment(SwingConstants.CENTER);
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 28)); // Professional font
        lblTitle.setBounds(10, 10, 760, 40);
        contentPane.add(lblTitle);

        // Subtitle
        JLabel lblSubtitle = new JLabel("Manage your market efficiently and seamlessly!");
        lblSubtitle.setHorizontalAlignment(SwingConstants.CENTER);
        lblSubtitle.setFont(new Font("Segoe UI", Font.ITALIC, 16)); // Lighter subtitle
        lblSubtitle.setBounds(10, 46, 760, 20);
        contentPane.add(lblSubtitle);

        // Separator below the title
        JSeparator titleSeparator = new JSeparator();
        titleSeparator.setBounds(10, 90, 760, 1);
        titleSeparator.setForeground(Color.GRAY);
        contentPane.add(titleSeparator);

        // Image Label
        lblNewLabel = new JLabel("");
        lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
        lblNewLabel.setBounds(20, 140, 490, 260);
        contentPane.add(lblNewLabel);

        // Set the image for the label
        setImage();

        // Time Display
        lblTime = new JLabel("Time: ");
        lblTime.setHorizontalAlignment(SwingConstants.LEFT);
        lblTime.setFont(new Font("Segoe UI", Font.PLAIN, 14)); // Clear and modern font
        lblTime.setBounds(10, 472, 200, 20);
        contentPane.add(lblTime);
        updateTime();

        // Separator between image and buttons
        JSeparator imageSeparator = new JSeparator();
        imageSeparator.setBounds(10, 461, 760, 1);
        imageSeparator.setForeground(Color.GRAY);
        contentPane.add(imageSeparator);

        // Log In Title above the buttons
        JLabel lblLogInTitle = new JLabel("Log In as:");
        lblLogInTitle.setHorizontalAlignment(SwingConstants.CENTER);
        lblLogInTitle.setFont(new Font("Segoe UI", Font.BOLD, 20)); // Modern and clear font
        lblLogInTitle.setBounds(520, 111, 250, 30); // Positioned above the button panel
        lblLogInTitle.setForeground(new Color(52, 73, 94)); // A darker shade for distinction
        contentPane.add(lblLogInTitle);

        // Role Buttons
        JPanel buttonPanel = new JPanel();
        buttonPanel.setBorder(new LineBorder(new Color(0, 0, 0), 4));
        buttonPanel.setBounds(453, 151, 317, 300);
        buttonPanel.setBackground(new Color(245, 245, 245)); // Match background
        contentPane.add(buttonPanel);
        buttonPanel.setLayout(null);

        // Buttons without icons
        JButton btnAdmin = createRoleButton("Admin", "Manage the system settings and users.", new Color(41, 128, 185), e -> {
            LogIn_Admin.main(null);
            dispose();
        });
        buttonPanel.add(btnAdmin);

        JButton btnClient = createRoleButton("Client", "Access client-specific dashboards.", new Color(39, 174, 96), e -> {
            LogIn_Client.main(null);
            dispose();
        });
        buttonPanel.add(btnClient);

        JButton btnUser = createRoleButton("User", "Log in as a general user.", new Color(211, 84, 0), e -> {
            LogIn_User.main(null);
            dispose();
        });
        buttonPanel.add(btnUser);

        // Help Button
        JButton btnHelp = new JButton("Help");
        btnHelp.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnHelp.setBounds(572, 462, 100, 40);
        btnHelp.setBackground(new Color(52, 152, 219));
        btnHelp.setForeground(Color.WHITE);
        btnHelp.setFocusPainted(false);
        btnHelp.setBorder(BorderFactory.createEmptyBorder());
        btnHelp.addActionListener(e -> showHelpDialog());
        contentPane.add(btnHelp);

        // Footer Label
        JLabel lblFooter = new JLabel("© 2024 Market Management System - All Rights Reserved");
        lblFooter.setHorizontalAlignment(SwingConstants.CENTER);
        lblFooter.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblFooter.setBounds(10, 530, 760, 20);
        lblFooter.setForeground(Color.DARK_GRAY);
        contentPane.add(lblFooter);

        // Update image size dynamically when the frame is resized
        addComponentListener(new ComponentAdapter() {
            public void componentResized(ComponentEvent evt) {
                setImage(); // Resize image whenever the window is resized
            }
        });
    }

    /**
     * Creates a JButton styled for role selection with tooltip and hover effect.
     */
    private JButton createRoleButton(String text, String tooltip, Color bgColor, ActionListener action) {
        JButton button = new JButton(text);
        button.setBounds(27, 21, 264, 70);
        button.setFont(new Font("Segoe UI", Font.BOLD, 16));
        button.setForeground(Color.WHITE);
        button.setBackground(bgColor);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(Color.DARK_GRAY, 2), // More defined border
            BorderFactory.createEmptyBorder(10, 15, 10, 15)
        ));

        // Tooltip and Action Listener
        button.setToolTipText(tooltip);
        button.addActionListener(action);

        // Hover effect
        button.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent evt) {
                button.setBackground(bgColor.darker());
            }

            public void mouseExited(MouseEvent evt) {
                button.setBackground(bgColor);
            }
        });

        return button;
    }

    /**
     * Sets the image in the JLabel and resizes it to fit the label size.
     */
    private void setImage() {
        try {
            ImageIcon icon = new ImageIcon(getClass().getResource("/images/LOGO.png")); // Load image from resources
            Image img = icon.getImage();
            img = img.getScaledInstance(lblNewLabel.getWidth(), lblNewLabel.getHeight(), Image.SCALE_SMOOTH); // Resize
            lblNewLabel.setIcon(new ImageIcon(img));
        } catch (Exception e) {
            lblNewLabel.setText("Image not found"); // Display message if image not found
        }
    }

    /**
     * Updates the time display every second.
     */
    private void updateTime() {
        Timer timer = new Timer(1000, e -> {
            lblTime.setText("Time: " + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));
        });
        timer.start();
    }

    /**
     * Displays a help dialog with system information.
     */
    private void showHelpDialog() {
        JOptionPane.showMessageDialog(this,
            "Market Management System\nVersion 1.0\n\nFor assistance, contact support@marketms.com",
            "Help", JOptionPane.INFORMATION_MESSAGE);
    }
}
