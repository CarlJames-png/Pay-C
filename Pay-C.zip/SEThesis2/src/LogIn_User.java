import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class LogIn_User extends JFrame {

    private JPanel contentPane;
    private JTextField txtUserName;
    private JPasswordField txtPassword;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                LogIn_User frame = new LogIn_User();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    /**
     * Create the frame.
     */
    public LogIn_User() {
        setTitle("PAY-C - Owner LogIn");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 600, 400);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(10, 10, 10, 10));
        contentPane.setBackground(new Color(245, 245, 245));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        // Title Label
        JLabel lblTitle = new JLabel("Owner Login");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 28));
        lblTitle.setHorizontalAlignment(SwingConstants.CENTER);
        lblTitle.setBounds(150, 10, 300, 40);
        contentPane.add(lblTitle);

        // Separator below the title
        JSeparator titleSeparator = new JSeparator();
        titleSeparator.setBounds(10, 58, 576, 2);
        titleSeparator.setForeground(Color.GRAY);
        contentPane.add(titleSeparator);

        // Picture/Logo Holder
        String imagePath = "C:\\Users\\Carl James Macapanas\\Desktop\\Pictures\\stalls\\product1 (3).jpg"; // Replace with the actual image path

        // Create a JLabel to act as the picture holder
        JLabel lblPicture = new JLabel();

        // Load the image and scale it to fit the desired area
        ImageIcon originalIcon = new ImageIcon(imagePath);  // Load the image
        Image img = originalIcon.getImage();  // Get the Image from the Icon
        Image scaledImg = img.getScaledInstance(200, 250, Image.SCALE_SMOOTH);  // Resize image to fit 200x250
        ImageIcon scaledIcon = new ImageIcon(scaledImg);  // Create an ImageIcon from the scaled image

        lblPicture.setIcon(scaledIcon);  // Set the scaled icon to the label
        lblPicture.setHorizontalAlignment(SwingConstants.CENTER);  // Center align the image
        lblPicture.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY));  // Add a light gray border
        lblPicture.setOpaque(true);  // Make the label opaque to set background color
        lblPicture.setBackground(Color.WHITE);  // Set a white background
        lblPicture.setBounds(20, 80, 200, 250);  // Set the size and position of the label
        contentPane.add(lblPicture);  // Add the label to the content pane


        // Username Label
        JLabel lblStall = new JLabel("Stall:");
        lblStall.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblStall.setBounds(250, 80, 100, 20);
        contentPane.add(lblStall);

        // Username TextField
        txtUserName = new JTextField();
        txtUserName.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtUserName.setBounds(250, 100, 300, 30);
        txtUserName.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        contentPane.add(txtUserName);

        // Password Label
        JLabel lblPassword = new JLabel("Password:");
        lblPassword.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblPassword.setBounds(250, 140, 100, 20);
        contentPane.add(lblPassword);

        // Password Field
        txtPassword = new JPasswordField();
        txtPassword.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtPassword.setBounds(250, 160, 300, 30);
        txtPassword.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        contentPane.add(txtPassword);

        // Login Button
        JButton btnLogin = new JButton("Login");
        btnLogin.setFont(new Font("Segoe UI", Font.BOLD, 16));
        btnLogin.setBackground(new Color(39, 174, 96)); // Green
        btnLogin.setForeground(Color.WHITE);
        btnLogin.setFocusPainted(false);
        btnLogin.setBounds(332, 200, 140, 40);
        btnLogin.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnLogin.addActionListener(e -> validateLogin());
        contentPane.add(btnLogin);

        // Back JLabel (Clickable)
        JLabel lblBack = new JLabel("< Back");
        lblBack.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblBack.setForeground(new Color(52, 152, 219)); // Blue color
        lblBack.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        lblBack.setBounds(20, 20, 80, 20);
        lblBack.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                MainLogin.main(null);
                dispose();
            }

            @Override
            public void mouseEntered(MouseEvent e) {
                lblBack.setForeground(new Color(41, 128, 185)); // Darker blue on hover
            }

            @Override
            public void mouseExited(MouseEvent e) {
                lblBack.setForeground(new Color(52, 152, 219)); // Reset to original color
            }
        });
        contentPane.add(lblBack);

        // Sign Up JLabel (Clickable)
        JLabel lblSignUp = new JLabel("Sign Up");
        lblSignUp.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblSignUp.setForeground(new Color(52, 152, 219)); // Blue color
        lblSignUp.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        lblSignUp.setBounds(379, 250, 55, 20);
        lblSignUp.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
               SignUp_User.main(null);
               dispose();
            }

            @Override
            public void mouseEntered(MouseEvent e) {
                lblSignUp.setForeground(new Color(41, 128, 185)); // Darker blue on hover
            }

            @Override
            public void mouseExited(MouseEvent e) {
                lblSignUp.setForeground(new Color(52, 152, 219)); // Reset to original color
            }
        });
        contentPane.add(lblSignUp);

        // Footer
        JLabel lblFooter = new JLabel("© 2024 Market Management System - All Rights Reserved");
        lblFooter.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblFooter.setHorizontalAlignment(SwingConstants.CENTER);
        lblFooter.setBounds(10, 340, 576, 20);
        lblFooter.setForeground(Color.DARK_GRAY);
        contentPane.add(lblFooter);
    }

    private void validateLogin() {
        String username = txtUserName.getText();
        String password = new String(txtPassword.getPassword());

        try {
            // Establish connection to MySQL database
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/sethesis", "root", "");

            // SQL query to check credentials and fetch stallName
            String query = "SELECT Stallname FROM userlog WHERE Stallname = ? AND password = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, username);
            stmt.setString(2, password);

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                String stallName = rs.getString("Stallname");

                // Redirect based on stallName
                switch (stallName.toLowerCase()) {
                    case "cocolemon":
                        User_Page_CocoLemon cocolemonPage = new User_Page_CocoLemon();
                        cocolemonPage.setVisible(true);
                        break;

                    case "burger":
                        User_Page_Burger burgerPage = new User_Page_Burger();
                        burgerPage.setVisible(true);
                        dispose();
                        break;

                    case "xhiawarma":
                        User_Page_Shawarma xhiawarmaPage = new User_Page_Shawarma();
                        xhiawarmaPage.setVisible(true);
                        dispose();
                        break;
                     
                    case "tindahan":
                        User_Page_Tindahan tindahanPage = new User_Page_Tindahan();
                        tindahanPage.setVisible(true);
                        dispose();
                        break;
                        
                    case "turon":
                        User_Page_Turon turonPage = new User_Page_Turon();
                        turonPage.setVisible(true);
                        dispose();
                        break;

                    default:
                        JOptionPane.showMessageDialog(this, "Unknown stall. Please contact support.", "Error", JOptionPane.ERROR_MESSAGE);
                }

                this.dispose(); // Close login window
            } else {
                JOptionPane.showMessageDialog(this, "Invalid Username or Password!", "Login Failed", JOptionPane.ERROR_MESSAGE);
            }

            // Close resources
            rs.close();
            stmt.close();
            conn.close();

        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "INVALID INPUT" + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }

    }
}
