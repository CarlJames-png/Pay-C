import java.awt.*;
import java.awt.event.ActionEvent;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

public class MainLogin extends JFrame {

    private JPanel contentPane;
    private JLabel lblTime;

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                MainLogin frame = new MainLogin();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public MainLogin() {
        setTitle("PAY-C - Login");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 900, 600);

        // Setting up the content pane
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(10, 10, 10, 10));
        contentPane.setBackground(Color.WHITE);
        setContentPane(contentPane);
        contentPane.setLayout(null);

        setupUIComponents();
        updateTime();
    }

    private void setupUIComponents() {
        // Title
        JLabel lblTitle = new JLabel("Welcome to PAY-C");
        lblTitle.setHorizontalAlignment(SwingConstants.CENTER);
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 30));
        lblTitle.setForeground(new Color(52, 73, 94));
        lblTitle.setBounds(10, 20, 860, 50);
        contentPane.add(lblTitle);

        // Subtitle
        JLabel lblSubtitle = new JLabel("Manage your market efficiently and seamlessly!");
        lblSubtitle.setHorizontalAlignment(SwingConstants.CENTER);
        lblSubtitle.setFont(new Font("Segoe UI", Font.ITALIC, 16));
        lblSubtitle.setForeground(new Color(127, 140, 141));
        lblSubtitle.setBounds(10, 70, 860, 20);
        contentPane.add(lblSubtitle);

        // Separator
        JSeparator separator = new JSeparator();
        separator.setBounds(10, 100, 860, 2);
        separator.setForeground(new Color(189, 195, 199));
        contentPane.add(separator);

        // Left Panel for Image Placeholder
        String imagePath = "C:\\Users\\Carl James Macapanas\\Desktop\\Pictures\\stalls\\product1 (1).jpg"; // Replace with actual image path
        ImageIcon originalIcon = new ImageIcon(imagePath);

        // Scale the image to fit the label's bounds
        Image img = originalIcon.getImage(); // Get the image
        Image scaledImg = img.getScaledInstance(400, 400, Image.SCALE_SMOOTH); // Scale it to 400x400, maintaining aspect ratio

        // Set the scaled image to the JLabel
        ImageIcon scaledIcon = new ImageIcon(scaledImg);
        JLabel lblImage = new JLabel(scaledIcon);
        lblImage.setHorizontalAlignment(SwingConstants.CENTER);
        lblImage.setBounds(30, 140, 400, 400); // Set the size of the JLabel
        lblImage.setBorder(BorderFactory.createLineBorder(new Color(189, 195, 199), 2));
        contentPane.add(lblImage);


        // Real-time clock
        lblTime = new JLabel("");
        lblTime.setHorizontalAlignment(SwingConstants.RIGHT);
        lblTime.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblTime.setForeground(new Color(149, 165, 166));
        lblTime.setBounds(750, 10, 130, 20);
        contentPane.add(lblTime);

        // Footer
        JLabel lblFooter = new JLabel("© 2024 Market Management System - All Rights Reserved");
        lblFooter.setHorizontalAlignment(SwingConstants.CENTER);
        lblFooter.setForeground(new Color(149, 165, 166));
        lblFooter.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblFooter.setBounds(10, 540, 860, 20);
        contentPane.add(lblFooter);

        // ADMIN Button
        JButton btnAdmin = createStyledButton("ADMIN");
        btnAdmin.addActionListener(e -> {
            LogIn_Admin.main(null); // Open Admin login page
            dispose(); // Close the current window
        });
        btnAdmin.setBounds(580, 220, 180, 50);
        contentPane.add(btnAdmin);

        // CLIENT Button
        JButton btnClient = createStyledButton("CUSTOMER");
        btnClient.addActionListener(e -> {
            LogIn_Client.main(null); // Open Client login page
            dispose(); // Close the current window
        });
        btnClient.setBounds(580, 300, 180, 50);
        contentPane.add(btnClient);

        // USER Button
        JButton btnUser = createStyledButton("OWNER");
        btnUser.addActionListener(e -> {
            LogIn_User.main(null); // Open User login page
            dispose(); // Close the current window
        });
        btnUser.setBounds(580, 380, 180, 50);
        contentPane.add(btnUser);

        
        JPanel panel = new JPanel();
        panel.setBounds(537, 140, 262, 328);
        contentPane.add(panel);
                panel.setLayout(null);
        
                // Login As Label
                JLabel lblLoginAs = new JLabel("Log in as:");
                lblLoginAs.setBounds(80, 31, 99, 30);
                panel.add(lblLoginAs);
                lblLoginAs.setHorizontalAlignment(SwingConstants.CENTER);
                lblLoginAs.setFont(new Font("Segoe UI", Font.BOLD, 22));
                lblLoginAs.setForeground(new Color(44, 62, 80));
    }

    private JButton createStyledButton(String text) {
        JButton button = new JButton(text);
        button.setFont(new Font("Segoe UI", Font.BOLD, 16));
        button.setForeground(Color.WHITE);
        button.setBackground(new Color(41, 128, 185));
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder());
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        button.setOpaque(true);

        // Shadow effect
        button.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(127, 140, 141), 1),
                BorderFactory.createEmptyBorder(10, 20, 10, 20)));

        // Hover effect
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(new Color(31, 97, 141));
            }

            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(new Color(41, 128, 185));
            }
        });

        return button;
    }

    private void updateTime() {
        Timer timer = new Timer(1000, e -> lblTime.setText(new SimpleDateFormat("HH:mm:ss").format(new Date())));
        timer.start();
    }
}
