import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.sql.*;

public class RealTimeTransaction extends JFrame {
    private JTabbedPane tabbedPane;
    private Timer refreshTimer;

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                RealTimeTransaction frame = new RealTimeTransaction();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public RealTimeTransaction() {
        setTitle("Transaction Records by Stall");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setBounds(100, 100, 800, 600);
        setLayout(new BorderLayout());  // Set BorderLayout for the main JFrame layout

        // Create a Back button with a more professional look
        JButton btnBack = new JButton("Back");
        btnBack.setFont(new Font("Segoe UI", Font.BOLD, 12));  // Slightly smaller font for a cleaner look
        btnBack.setPreferredSize(new Dimension(100, 30));  // Smaller, more compact button
        btnBack.setBackground(new Color(70, 130, 180));  // A nice blue background color
        btnBack.setForeground(Color.WHITE);  // White text for contrast
        btnBack.setBorder(BorderFactory.createLineBorder(new Color(70, 130, 180), 2));  // Border matching the button color
        btnBack.setFocusPainted(false);  // Remove focus paint (no glowing effect on click)

        // Add hover effect
        btnBack.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnBack.setBackground(new Color(100, 149, 237));  // Lighter blue when hovering
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnBack.setBackground(new Color(70, 130, 180));  // Original blue when not hovering
            }
        });

        // Action listener to go back to Admin_Page_MAIN
        btnBack.addActionListener(e -> {
            // Close the current frame (RealTimeTransaction) and open Admin_Page_MAIN
            dispose();  // Dispose the current window (RealTimeTransaction)
            new Admin_Page_MAIN().setVisible(true);  // Create and show the Admin Page Main
        });

        // Create a panel with FlowLayout and left alignment for the Back button
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));  // Left-aligned button
        topPanel.add(btnBack);  // Add button to the panel
        add(topPanel, BorderLayout.NORTH);  // Add the panel to the NORTH region of the BorderLayout

        // Create the tabbed panel where the transaction records will be shown
        tabbedPane = new JTabbedPane();
        add(tabbedPane, BorderLayout.CENTER);  // Add the tabbed pane to the CENTER region

        // Add tabs for each stall
        addStallTab("Burger", "orders_burger");
        addStallTab("Turon", "orders_turon");
        addStallTab("Cocolemon", "orders_cocolemon");
        addStallTab("Shawarma", "orders_shawarma");
        addStallTab("Tindahan", "orders_tindahan");

        // Polling every 5 seconds (5000 milliseconds) to refresh data
        refreshTimer = new Timer(5000, e -> refreshAllTabs());
        refreshTimer.start();
    }

    private void addStallTab(String name, String tableName) {
        JPanel stallPanel = new JPanel();
        stallPanel.setLayout(new BorderLayout());

        JTable transactionTable = new JTable();
        DefaultTableModel tableModel = new DefaultTableModel(new String[]{"Order Details", "Payment Method", "Order Date"}, 0);
        transactionTable.setModel(tableModel);

        JScrollPane scrollPane = new JScrollPane(transactionTable);
        stallPanel.add(scrollPane, BorderLayout.CENTER);

        JButton btnLoad = new JButton("Load Transactions");
        btnLoad.addActionListener(e -> loadTransactions(tableModel, tableName));
        stallPanel.add(btnLoad, BorderLayout.SOUTH);

        tabbedPane.addTab(name, stallPanel);

        // Load data on startup for this tab
        loadTransactions(tableModel, tableName);
    }

    private void loadTransactions(DefaultTableModel tableModel, String tableName) {
        tableModel.setRowCount(0); // Clear the existing table data
        String query = "SELECT order_details, payment_method, order_date FROM " + tableName;

        try (Connection conn = connectToDatabase();
             PreparedStatement stmt = conn.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                tableModel.addRow(new Object[] {
                    rs.getString("order_details"),
                    rs.getString("payment_method"),
                    rs.getString("order_date")
                });
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading transactions for " + tableName + ".");
        }
    }

    private void refreshAllTabs() {
        for (int i = 0; i < tabbedPane.getTabCount(); i++) {
            JPanel stallPanel = (JPanel) tabbedPane.getComponentAt(i);
            JScrollPane scrollPane = (JScrollPane) stallPanel.getComponent(0);
            JTable transactionTable = (JTable) scrollPane.getViewport().getView();
            DefaultTableModel tableModel = (DefaultTableModel) transactionTable.getModel();

            String tableName = switch (tabbedPane.getTitleAt(i)) {
                case "Burger" -> "orders_burger";
                case "Turon" -> "orders_turon";
                case "Cocolemon" -> "orders_cocolemon";
                case "Shawarma" -> "orders_shawarma";
                case "Tindahan" -> "orders_tindahan";
                default -> throw new IllegalStateException("Unexpected stall name.");
            };

            loadTransactions(tableModel, tableName);
        }
    }

    private Connection connectToDatabase() throws SQLException {
        String url = "jdbc:mysql://localhost:3306/sethesis";
        String user = "root";
        String password = "";
        return DriverManager.getConnection(url, user, password);
    }
}
