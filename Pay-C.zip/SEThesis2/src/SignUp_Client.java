import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.*;
import javax.swing.border.EmptyBorder;


public class SignUp_Client extends JFrame {

    private JPanel contentPane;
    private JTextField txtFirstName, txtLastName, txtEmail;
    private JPasswordField txtPassword, txtConfirmPassword;
    private JCheckBox chkTerms;
    private JTextField txtMobileNumber;
    private JComboBox<String> cmbGender;
    private JTextField txtBirthday;

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                SignUp_Client frame = new SignUp_Client();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public SignUp_Client() {
        // Frame settings
        setTitle("Client Sign-Up");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 738, 621);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(10, 10, 10, 10));
        contentPane.setBackground(new Color(245, 245, 245));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        // Title
        JLabel lblTitle = new JLabel("Create Your Account");
        lblTitle.setHorizontalAlignment(SwingConstants.CENTER);
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 28));
        lblTitle.setBounds(194, 4, 365, 40);
        contentPane.add(lblTitle);

        // Subtitle
        JLabel lblSubtitle = new JLabel("Join us to manage your market efficiently!");
        lblSubtitle.setHorizontalAlignment(SwingConstants.CENTER);
        lblSubtitle.setFont(new Font("Segoe UI", Font.ITALIC, 16));
        lblSubtitle.setBounds(10, 50, 760, 20);
        contentPane.add(lblSubtitle);

        // Separator
        JSeparator separator = new JSeparator();
        separator.setBounds(10, 80, 710, 2);
        separator.setForeground(Color.BLACK);
        contentPane.add(separator);

        // Picture Placeholder
        String imagePath = "C:\\Users\\Carl James Macapanas\\Desktop\\Pictures\\stalls\\product1 (5).jpg"; // Replace with your actual image path

        // Create a JLabel to act as the picture holder
        JLabel lblPicture = new JLabel();

        // Set the image path
        ImageIcon originalIcon = new ImageIcon(imagePath);  // Load the image
        Image img = originalIcon.getImage();  // Get the Image from the Icon
        Image scaledImg = img.getScaledInstance(327, 411, Image.SCALE_SMOOTH);  // Resize image to fit 327x411
        ImageIcon scaledIcon = new ImageIcon(scaledImg);  // Create an ImageIcon from the scaled image

        // Set the image icon to the label
        lblPicture.setIcon(scaledIcon);

        // Set properties for the label
        lblPicture.setHorizontalAlignment(SwingConstants.CENTER);  // Center align the image
        lblPicture.setFont(new Font("Segoe UI", Font.PLAIN, 18));  // Font for the placeholder text (optional)
        lblPicture.setText("Picture Placeholder");  // Placeholder text if the image is not loaded or in case of loading delay
        lblPicture.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY));  // Light gray border
        lblPicture.setBounds(20, 100, 327, 411);  // Set the size and position of the label
        lblPicture.setOpaque(true);  // Make the label opaque to set background color
        lblPicture.setBackground(Color.WHITE);  // Set a white background

        // Add the picture holder to the content pane
        contentPane.add(lblPicture);


        // First Name
        JLabel lblFirstName = new JLabel("First Name:");
        lblFirstName.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblFirstName.setBounds(370, 92, 100, 25);
        contentPane.add(lblFirstName);

        txtFirstName = new JTextField();
        txtFirstName.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtFirstName.setBounds(370, 112, 300, 25);
        contentPane.add(txtFirstName);

        // Last Name
        JLabel lblLastName = new JLabel("Last Name:");
        lblLastName.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblLastName.setBounds(370, 147, 100, 25);
        contentPane.add(lblLastName);

        txtLastName = new JTextField();
        txtLastName.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtLastName.setBounds(370, 167, 300, 25);
        contentPane.add(txtLastName);

        // Email
        JLabel lblEmail = new JLabel("Email Address:");
        lblEmail.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblEmail.setBounds(370, 202, 100, 25);
        contentPane.add(lblEmail);

        txtEmail = new JTextField();
        txtEmail.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtEmail.setBounds(370, 222, 300, 25);
        contentPane.add(txtEmail);

        // Password
        JLabel lblPassword = new JLabel("Password:");
        lblPassword.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblPassword.setBounds(370, 257, 100, 25);
        contentPane.add(lblPassword);

        txtPassword = new JPasswordField();
        txtPassword.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtPassword.setBounds(370, 279, 300, 25);
        contentPane.add(txtPassword);

        // Confirm Password
        JLabel lblConfirmPassword = new JLabel("Confirm Password:");
        lblConfirmPassword.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblConfirmPassword.setBounds(369, 314, 130, 25);
        contentPane.add(lblConfirmPassword);

        txtConfirmPassword = new JPasswordField();
        txtConfirmPassword.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtConfirmPassword.setBounds(370, 336, 300, 25);
        contentPane.add(txtConfirmPassword);

        // Terms and Conditions
        chkTerms = new JCheckBox("I accept the terms and conditions");
        chkTerms.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        chkTerms.setBackground(new Color(245, 245, 245));
        chkTerms.setBounds(399, 482, 248, 25);
        contentPane.add(chkTerms);

        // Register Button
        JButton btnRegister = new JButton("Register");
        btnRegister.setFont(new Font("Segoe UI", Font.BOLD, 16));
        btnRegister.setBounds(379, 513, 120, 40);
        btnRegister.setBackground(new Color(41, 128, 185));
        btnRegister.setForeground(Color.WHITE);
        btnRegister.setFocusPainted(false);
        btnRegister.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        contentPane.add(btnRegister);

        // Clear Button
        JButton btnClear = new JButton("Clear");
        btnClear.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                clearFields();  // Call clearFields method when the button is clicked
            }
        });

        btnClear.setFont(new Font("Segoe UI", Font.BOLD, 16));
        btnClear.setBounds(510, 513, 120, 40);
        btnClear.setBackground(new Color(211, 84, 0));
        btnClear.setForeground(Color.WHITE);
        btnClear.setFocusPainted(false);
        btnClear.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        contentPane.add(btnClear);
        
        // Mobile Number
        JLabel lblMobileNumber = new JLabel("Mobile Number:");
        lblMobileNumber.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblMobileNumber.setBounds(370, 371, 129, 25);
        contentPane.add(lblMobileNumber);

        txtMobileNumber = new JTextField();
        txtMobileNumber.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtMobileNumber.setBounds(370, 392, 300, 25);
        contentPane.add(txtMobileNumber);

        // Gender
        JLabel lblGender = new JLabel("Gender:");
        lblGender.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblGender.setBounds(370, 427, 100, 25);
        contentPane.add(lblGender);

        cmbGender = new JComboBox<>(new DefaultComboBoxModel<>(new String[]{"Male", "Female", "Other"}));
        cmbGender.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        cmbGender.setBounds(370, 451, 100, 25);
        contentPane.add(cmbGender);

        // Birthday
        JLabel lblBirthday = new JLabel("Birthday (yyyy-mm-dd):");
        lblBirthday.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblBirthday.setBounds(497, 427, 150, 25);
        contentPane.add(lblBirthday);

        txtBirthday = new JTextField();
        txtBirthday.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtBirthday.setBounds(497, 450, 173, 25);
        contentPane.add(txtBirthday);

        // Footer
        JLabel lblFooter = new JLabel("© 2024 Market Management System - All Rights Reserved");
        lblFooter.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblFooter.setHorizontalAlignment(SwingConstants.CENTER);
        lblFooter.setBounds(-30, 563, 760, 20);
        contentPane.add(lblFooter);
        
        // Back JLabel (Clickable)
        JLabel lblBack = new JLabel("< Back");
        lblBack.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblBack.setForeground(new Color(52, 152, 219)); // Blue color
        lblBack.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        lblBack.setBounds(20, 20, 80, 20);
        lblBack.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                MainLogin.main(null);
                dispose();
            }

            @Override
            public void mouseEntered(MouseEvent e) {
                lblBack.setForeground(new Color(41, 128, 185)); // Darker blue on hover
            }

            @Override
            public void mouseExited(MouseEvent e) {
                lblBack.setForeground(new Color(52, 152, 219)); // Reset to original color
            }
        });
        contentPane.add(lblBack);

        // Action listeners
        btnRegister.addActionListener(e -> registerUser());
    }

    // Code for registering user
    private void registerUser() {
        String firstName = txtFirstName.getText().trim();
        String lastName = txtLastName.getText().trim();
        String email = txtEmail.getText().trim();
        String password = new String(txtPassword.getPassword());
        String confirmPassword = new String(txtConfirmPassword.getPassword());
        String mobileNumber = txtMobileNumber.getText().trim();
        String gender = (String) cmbGender.getSelectedItem();
        String birthdayString = txtBirthday.getText().trim();

        // Validation logic here
        if (firstName.isEmpty() || lastName.isEmpty() || email.isEmpty() || password.isEmpty() || confirmPassword.isEmpty() || mobileNumber.isEmpty() || gender == null || birthdayString.isEmpty()) {
            JOptionPane.showMessageDialog(this, "All fields must be filled!", "Validation Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Sanitize mobile number to remove any non-digit characters
        mobileNumber = mobileNumber.replaceAll("\\D", "");
        if (mobileNumber.length() != 10) {
            JOptionPane.showMessageDialog(this, "Invalid mobile number! It must be 10 digits.", "Validation Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Password validation (check if password and confirm password match)
        if (!password.equals(confirmPassword)) {
            JOptionPane.showMessageDialog(this, "Passwords do not match!", "Validation Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Validate the birthday format (yyyy-mm-dd)
        if (!birthdayString.matches("\\d{4}-\\d{2}-\\d{2}")) {
            JOptionPane.showMessageDialog(this, "Invalid birthday format! Use yyyy-mm-dd.", "Validation Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Convert the birthday string to a java.sql.Date
        java.sql.Date birthday = null;
        try {
            birthday = java.sql.Date.valueOf(birthdayString); // Convert string to SQL Date
        } catch (IllegalArgumentException e) {
            JOptionPane.showMessageDialog(this, "Invalid date entered!", "Validation Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/sethesis", "root", "")) {
            String checkEmailQuery = "SELECT COUNT(*) FROM clientLog WHERE email = ?";
            try (PreparedStatement checkStmt = conn.prepareStatement(checkEmailQuery)) {
                checkStmt.setString(1, email);
                ResultSet rs = checkStmt.executeQuery();
                if (rs.next() && rs.getInt(1) > 0) {
                    JOptionPane.showMessageDialog(this, "Email is already registered!", "Validation Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
            }

            String insertQuery = "INSERT INTO clientLog (first_name, last_name, email, password, mobile_number, gender, birthday) VALUES (?, ?, ?, ?, ?, ?, ?)";
            try (PreparedStatement stmt = conn.prepareStatement(insertQuery)) {
                stmt.setString(1, firstName);
                stmt.setString(2, lastName);
                stmt.setString(3, email);
                stmt.setString(4, password);
                stmt.setString(5, mobileNumber);
                stmt.setString(6, gender);
                stmt.setDate(7, birthday);

                int result = stmt.executeUpdate();
                if (result > 0) {
                    JOptionPane.showMessageDialog(this, "Registration successful!", "Success", JOptionPane.INFORMATION_MESSAGE);
                    clearFields();
                    LogIn_Client.main(null);
                    dispose();
                } else {
                    JOptionPane.showMessageDialog(this, "Registration failed. Try again.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "An error occurred. Please try again later.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }


    // Update the clearFields method to reset new fields
    private void clearFields() {
        txtFirstName.setText("");
        txtLastName.setText("");
        txtEmail.setText("");
        txtPassword.setText("");
        txtConfirmPassword.setText("");
        txtMobileNumber.setText("");
        cmbGender.setSelectedIndex(0);
        txtBirthday.setText("");
        chkTerms.setSelected(false);
    }
}
