import java.awt.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

public class SignUp_User extends JFrame {

    private JPanel contentPane;
    private JTextField txtStallName;
    private JPasswordField txtPassword, txtConfirmPassword;
    private JComboBox<String> cmbCategory;

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                SignUp_User frame = new SignUp_User();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public SignUp_User() {
        // Frame settings
        setTitle("Stall Owner Sign-Up");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 744, 600);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(10, 10, 10, 10));
        contentPane.setBackground(new Color(245, 245, 245));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        // Title
        JLabel lblTitle = new JLabel("Register Your Stall");
        lblTitle.setHorizontalAlignment(SwingConstants.CENTER);
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 28));
        lblTitle.setBounds(194, 4, 365, 40);
        contentPane.add(lblTitle);

        // Subtitle
        JLabel lblSubtitle = new JLabel("Join our platform to manage your stall efficiently!");
        lblSubtitle.setHorizontalAlignment(SwingConstants.CENTER);
        lblSubtitle.setFont(new Font("Segoe UI", Font.ITALIC, 16));
        lblSubtitle.setBounds(10, 50, 710, 20);
        contentPane.add(lblSubtitle);

        // Separator
        JSeparator separator = new JSeparator();
        separator.setBounds(10, 80, 710, 2);
        separator.setForeground(Color.BLACK);
        contentPane.add(separator);

        // Picture Placeholder
        String imagePath = "C:\\Users\\Carl James Macapanas\\Desktop\\Pictures\\stalls\\product1 (6).jpg"; // Replace with your actual image path

        // Create a JLabel to act as the picture holder
        JLabel lblPicture = new JLabel();

        // Set the image path
        ImageIcon originalIcon = new ImageIcon(imagePath);  // Load the image
        Image img = originalIcon.getImage();  // Get the Image from the Icon
        Image scaledImg = img.getScaledInstance(327, 411, Image.SCALE_SMOOTH);  // Resize image to fit 327x411
        ImageIcon scaledIcon = new ImageIcon(scaledImg);  // Create an ImageIcon from the scaled image

        // Set the image icon to the label
        lblPicture.setIcon(scaledIcon);

        // Set properties for the label
        lblPicture.setHorizontalAlignment(SwingConstants.CENTER);  // Center align the image
        lblPicture.setFont(new Font("Segoe UI", Font.PLAIN, 18));  // Font for the placeholder text (optional)
        lblPicture.setText("Picture Placeholder");  // Placeholder text if the image is not loaded or in case of loading delay
        lblPicture.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY));  // Light gray border
        lblPicture.setBounds(20, 100, 327, 411);  // Set the size and position of the label
        lblPicture.setOpaque(true);  // Make the label opaque to set background color
        lblPicture.setBackground(Color.WHITE);  // Set a white background

        // Add the picture holder to the content pane
        contentPane.add(lblPicture);


        // Stall Name
        JLabel lblStallName = new JLabel("Stall Name:");
        lblStallName.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblStallName.setBounds(370, 130, 100, 25);
        contentPane.add(lblStallName);

        txtStallName = new JTextField();
        txtStallName.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtStallName.setBounds(370, 155, 300, 25);
        contentPane.add(txtStallName);

        // Category
        JLabel lblCategory = new JLabel("Category:");
        lblCategory.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblCategory.setBounds(370, 185, 100, 25);
        contentPane.add(lblCategory);

        // JComboBox
        String[] categories = {"Select Category", "Food", "Clothing", "Electronics", "Crafts", "Books", "Other"};
        cmbCategory = new JComboBox<>(new DefaultComboBoxModel<>(categories));
        cmbCategory.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        cmbCategory.setBounds(370, 210, 300, 25);
        contentPane.add(cmbCategory);


        // Password
        JLabel lblPassword = new JLabel("Password:");
        lblPassword.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblPassword.setBounds(370, 240, 100, 25);
        contentPane.add(lblPassword);

        txtPassword = new JPasswordField();
        txtPassword.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtPassword.setBounds(370, 265, 300, 25);
        contentPane.add(txtPassword);

        // Confirm Password
        JLabel lblConfirmPassword = new JLabel("Confirm Password:");
        lblConfirmPassword.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblConfirmPassword.setBounds(370, 295, 130, 25);
        contentPane.add(lblConfirmPassword);

        txtConfirmPassword = new JPasswordField();
        txtConfirmPassword.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtConfirmPassword.setBounds(370, 320, 300, 25);
        contentPane.add(txtConfirmPassword);

        // Terms Checkbox
        JCheckBox chkTerms = new JCheckBox("I accept the terms and conditions");
        chkTerms.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        chkTerms.setBackground(new Color(245, 245, 245));
        chkTerms.setBounds(370, 355, 300, 25);
        contentPane.add(chkTerms);

        // Register Button
        JButton btnRegister = new JButton("Register");
        btnRegister.setFont(new Font("Segoe UI", Font.BOLD, 16));
        btnRegister.setBounds(392, 400, 120, 40);
        btnRegister.setBackground(new Color(41, 128, 185));
        btnRegister.setForeground(Color.WHITE);
        btnRegister.setFocusPainted(false);
        btnRegister.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnRegister.addActionListener(e -> registerStall(chkTerms.isSelected()));
        contentPane.add(btnRegister);

        // Clear Button
        JButton btnClear = new JButton("Clear");
        btnClear.setFont(new Font("Segoe UI", Font.BOLD, 16));
        btnClear.setBounds(520, 400, 120, 40);
        btnClear.setBackground(new Color(211, 84, 0));
        btnClear.setForeground(Color.WHITE);
        btnClear.setFocusPainted(false);
        btnClear.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnClear.addActionListener(e -> clearFields());
        contentPane.add(btnClear);

        // Back Button
        JLabel lblBack = new JLabel("< Back");
        lblBack.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblBack.setForeground(new Color(52, 152, 219));
        lblBack.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        lblBack.setBounds(20, 20, 80, 20);
        lblBack.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                MainLogin.main(null);
            }

            @Override
            public void mouseEntered(MouseEvent e) {
                lblBack.setForeground(new Color(41, 128, 185));
            }

            @Override
            public void mouseExited(MouseEvent e) {
                lblBack.setForeground(new Color(52, 152, 219));
            }
        });
        contentPane.add(lblBack);

        // Footer
        JLabel lblFooter = new JLabel("© 2024 Market Management System - All Rights Reserved");
        lblFooter.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblFooter.setHorizontalAlignment(SwingConstants.CENTER);
        lblFooter.setBounds(10, 533, 710, 20);
        contentPane.add(lblFooter);
    }

    private void registerStall(boolean termsAccepted) {
        String stallName = txtStallName.getText().trim();
        String category = (String) cmbCategory.getSelectedItem();
        String password = new String(txtPassword.getPassword());
        String confirmPassword = new String(txtConfirmPassword.getPassword());

        if (stallName.isEmpty() || password.isEmpty() || confirmPassword.isEmpty() || "Select Category".equals(category)) {
            JOptionPane.showMessageDialog(this, "All fields are required!", "Validation Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (!termsAccepted) {
            JOptionPane.showMessageDialog(this, "You must accept the terms and conditions!", "Validation Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (password.length() < 6 || !password.matches(".*[A-Za-z].*") || !password.matches(".*\\d.*")) {
            JOptionPane.showMessageDialog(this, "Password must be at least 6 characters long and include letters and numbers!", "Validation Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (!password.equals(confirmPassword)) {
            JOptionPane.showMessageDialog(this, "Passwords do not match!", "Validation Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/sethesis", "root", "")) {
            String query = "INSERT INTO userLog (Stallname, Category, Password) VALUES (?, ?, ?)";
            try (PreparedStatement stmt = conn.prepareStatement(query)) {
                stmt.setString(1, stallName);
                stmt.setString(2, category);
                stmt.setString(3, password);

                int result = stmt.executeUpdate();
                if (result > 0) {
                    JOptionPane.showMessageDialog(this, "Registration successful!", "Success", JOptionPane.INFORMATION_MESSAGE);
                    clearFields();
                } else {
                    JOptionPane.showMessageDialog(this, "Registration failed. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void clearFields() {
        txtStallName.setText("");
        cmbCategory.setSelectedIndex(0);
        txtPassword.setText("");
        txtConfirmPassword.setText("");
    }
}
