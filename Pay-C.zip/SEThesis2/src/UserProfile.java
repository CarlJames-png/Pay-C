import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class UserProfile extends JFrame {
    private JTextField txtName, txtEmail, txtPhone;

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                UserProfile frame = new UserProfile();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public UserProfile() {
        setTitle("User Profile");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setBounds(100, 100, 400, 400);
        JPanel contentPane = new JPanel();
        contentPane.setLayout(null);
        setContentPane(contentPane);

        JLabel lblName = new JLabel("Name:");
        lblName.setBounds(20, 20, 100, 25);
        contentPane.add(lblName);

        txtName = new JTextField();
        txtName.setBounds(120, 20, 200, 25);
        contentPane.add(txtName);

        JLabel lblEmail = new JLabel("Email:");
        lblEmail.setBounds(20, 60, 100, 25);
        contentPane.add(lblEmail);

        txtEmail = new JTextField();
        txtEmail.setBounds(120, 60, 200, 25);
        contentPane.add(txtEmail);

        JLabel lblPhone = new JLabel("Phone:");
        lblPhone.setBounds(20, 100, 100, 25);
        contentPane.add(lblPhone);

        txtPhone = new JTextField();
        txtPhone.setBounds(120, 100, 200, 25);
        contentPane.add(txtPhone);

        JButton btnSave = new JButton("Save");
        btnSave.setBounds(50, 200, 100, 30);
        btnSave.addActionListener(e -> saveProfile());
        contentPane.add(btnSave);

        JButton btnDelete = new JButton("Delete Profile");
        btnDelete.setBounds(200, 200, 150, 30);
        btnDelete.addActionListener(e -> deleteProfile());
        contentPane.add(btnDelete);

        loadProfile();
    }

    private void loadProfile() {
        try (Connection conn = connectToDatabase();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM clientlog WHERE id = 1")) {
            if (rs.next()) {
                txtName.setText(rs.getString("name"));
                txtEmail.setText(rs.getString("email"));
                txtPhone.setText(rs.getString("phone"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading profile.");
        }
    }

    private void saveProfile() {
        try (Connection conn = connectToDatabase();
             PreparedStatement stmt = conn.prepareStatement("UPDATE clientlog SET name = ?, email = ?, phone = ? WHERE id = 1")) {
            stmt.setString(1, txtName.getText());
            stmt.setString(2, txtEmail.getText());
            stmt.setString(3, txtPhone.getText());
            stmt.executeUpdate();
            JOptionPane.showMessageDialog(this, "Profile saved successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error saving profile.");
        }
    }

    private void deleteProfile() {
        try (Connection conn = connectToDatabase();
             PreparedStatement stmt = conn.prepareStatement("DELETE FROM clientlog WHERE id = 1")) {
            stmt.executeUpdate();
            JOptionPane.showMessageDialog(this, "Profile deleted successfully.");
            System.exit(0);
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error deleting profile.");
        }
    }

    private Connection connectToDatabase() throws SQLException {
        String url = "jdbc:mysql://localhost:3306/sethesis";
        String user = "root";
        String password = "";
        return DriverManager.getConnection(url, user, password);
    }
}
