import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;

public class User_Page_Burger_Inventory extends JFrame {

    private JPanel contentPane;
    private JTable table;
    private DefaultTableModel tableModel;
    private JTextField searchField;
    private Connection connection;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                User_Page_Burger_Inventory frame = new User_Page_Burger_Inventory();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    /**
     * Create the frame.
     */
    public User_Page_Burger_Inventory() {
        setTitle("Coco Lemon Inventory");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 800, 500);

        // Database Connection
        connectToDatabase();

        // Main Content Pane
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(10, 10, 10, 10));
        contentPane.setLayout(new BorderLayout(10, 10));
        setContentPane(contentPane);

        // Header
        JLabel lblTitle = new JLabel("Burger Inventory");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 24));
        lblTitle.setHorizontalAlignment(SwingConstants.CENTER);
        lblTitle.setForeground(new Color(41, 128, 185));
        contentPane.add(lblTitle, BorderLayout.NORTH);
        
        // Back Button
        JLabel lblBack = new JLabel("<Back");
        lblBack.setForeground(new Color(52, 152, 219));
        lblBack.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblBack.setBounds(20, 23, 80, 20);
        lblBack.setCursor(new Cursor(Cursor.HAND_CURSOR));
        contentPane.add(lblBack);

        lblBack.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent evt) {
                User_Page_Burger.main(null);
                dispose();
            }
        });

        // Table Panel
        JPanel tablePanel = new JPanel(new BorderLayout());
        contentPane.add(tablePanel, BorderLayout.CENTER);

        // Table Model and Table
        tableModel = new DefaultTableModel(new Object[]{"ID", "Product Name", "Description", "Price", "Stock"}, 0);
        table = new JTable(tableModel);
        styleTable();

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(new LineBorder(new Color(41, 128, 185), 1, true));
        tablePanel.add(scrollPane, BorderLayout.CENTER);

        // Search Panel
        JPanel searchPanel = new JPanel(new BorderLayout(5, 5));
        searchField = new JTextField();
        searchField.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        searchField.setPreferredSize(new Dimension(200, 30));

        JButton btnSearch = new JButton("Search");
        btnSearch.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnSearch.setBackground(new Color(41, 128, 185));
        btnSearch.setForeground(Color.WHITE);
        btnSearch.setFocusPainted(false);
        btnSearch.addActionListener(e -> searchInventory());

        JButton btnShowAll = new JButton("Show All");
        btnShowAll.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnShowAll.setBackground(new Color(39, 174, 96));
        btnShowAll.setForeground(Color.WHITE);
        btnShowAll.setFocusPainted(false);
        btnShowAll.addActionListener(e -> fetchAndDisplayInventory());

        JPanel buttonsPanel1 = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
        buttonsPanel1.add(btnSearch);
        buttonsPanel1.add(btnShowAll);

        searchPanel.add(searchField, BorderLayout.CENTER);
        searchPanel.add(buttonsPanel1, BorderLayout.EAST);
        tablePanel.add(searchPanel, BorderLayout.NORTH);

        // Button Panel
        JPanel buttonsPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        contentPane.add(buttonsPanel, BorderLayout.SOUTH);

        JButton btnAdd = createButton("Add Product", new Color(46, 204, 113));
        JButton btnEdit = createButton("Edit Product", new Color(241, 196, 15));
        JButton btnDelete = createButton("Delete Product", new Color(231, 76, 60));
        JButton btnRefresh = createButton("Refresh", new Color(39, 174, 96));

        buttonsPanel.add(btnAdd);
        buttonsPanel.add(btnEdit);
        buttonsPanel.add(btnDelete);
        buttonsPanel.add(btnRefresh);

        // Button Actions
        btnAdd.addActionListener(e -> openProductDialog("Add Product", null));
        btnEdit.addActionListener(e -> openEditProductDialog());
        btnDelete.addActionListener(e -> deleteSelectedProduct());
        btnRefresh.addActionListener(e -> fetchAndDisplayInventory());

        // Load Inventory
        fetchAndDisplayInventory();
    }

    private void connectToDatabase() {
        try {
            String url = "jdbc:mysql://localhost:3306/sethesis";
            String user = "root";
            String password = ""; // Update with your password
            connection = DriverManager.getConnection(url, user, password);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Failed to connect to the database.", "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
            System.exit(1);
        }
    }

    private JButton createButton(String text, Color bgColor) {
        JButton button = new JButton(text);
        button.setFont(new Font("Segoe UI", Font.BOLD, 14));
        button.setBackground(bgColor);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setPreferredSize(new Dimension(150, 40));
        return button;
    }

    private void styleTable() {
        table.setRowHeight(30);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 14));
        table.getTableHeader().setBackground(new Color(41, 128, 185));
        table.getTableHeader().setForeground(Color.WHITE);
        table.setSelectionBackground(new Color(41, 128, 185));
        table.setSelectionForeground(Color.WHITE);
        table.setGridColor(new Color(200, 200, 200));
    }

    private void fetchAndDisplayInventory() {
        // Clear Table
        tableModel.setRowCount(0);

        // Fetch Data from Database
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM stallburger")) {

            while (rs.next()) {
                tableModel.addRow(new Object[]{
                    rs.getInt("id"),
                    rs.getString("name"),
                    rs.getString("description"),
                    rs.getDouble("price"),
                    rs.getInt("stock")
                });
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Failed to load inventory data: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }

    private void searchInventory() {
        String keyword = searchField.getText().trim();
        if (keyword.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter a search term.", "Empty Search", JOptionPane.WARNING_MESSAGE);
            fetchAndDisplayInventory(); // Reset the table to show all products
            return;
        }

        try (PreparedStatement stmt = connection.prepareStatement(
                "SELECT * FROM stallburger WHERE LOWER(name) LIKE ? OR LOWER(description) LIKE ?")) {
            stmt.setString(1, "%" + keyword.toLowerCase() + "%");
            stmt.setString(2, "%" + keyword.toLowerCase() + "%");

            ResultSet rs = stmt.executeQuery();
            tableModel.setRowCount(0); // Clear the table

            boolean foundResults = false;

            while (rs.next()) {
                foundResults = true;
                tableModel.addRow(new Object[]{
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("description"),
                        rs.getDouble("price"),
                        rs.getInt("stock")
                });
            }

            if (!foundResults) {
                JOptionPane.showMessageDialog(this, "No products match your search.", "Search Results", JOptionPane.INFORMATION_MESSAGE);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Search operation failed: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }


    private void openProductDialog(String title, Object[] product) {
        JDialog dialog = new JDialog(this, title, true);
        dialog.setSize(400, 300);
        dialog.getContentPane().setLayout(new GridLayout(5, 2, 10, 10));
        dialog.setLocationRelativeTo(this);

        JLabel lblName = new JLabel("Product Name:");
        JTextField txtName = new JTextField(product != null ? (String) product[1] : "");

        JLabel lblDescription = new JLabel("Description:");
        JTextField txtDescription = new JTextField(product != null ? (String) product[2] : "");

        JLabel lblPrice = new JLabel("Price:");
        JTextField txtPrice = new JTextField(product != null ? product[3].toString() : "");

        JLabel lblStock = new JLabel("Stock:");
        JTextField txtStock = new JTextField(product != null ? product[4].toString() : "");

        JButton btnSave = new JButton("Save");
        JButton btnCancel = new JButton("Cancel");

        dialog.getContentPane().add(lblName);
        dialog.getContentPane().add(txtName);
        dialog.getContentPane().add(lblDescription);
        dialog.getContentPane().add(txtDescription);
        dialog.getContentPane().add(lblPrice);
        dialog.getContentPane().add(txtPrice);
        dialog.getContentPane().add(lblStock);
        dialog.getContentPane().add(txtStock);
        dialog.getContentPane().add(btnSave);
        dialog.getContentPane().add(btnCancel);

        btnSave.addActionListener(e -> {
            String name = txtName.getText();
            String description = txtDescription.getText();
            String priceText = txtPrice.getText();
            String stockText = txtStock.getText();

            if (name.isEmpty() || description.isEmpty() || priceText.isEmpty() || stockText.isEmpty()) {
                JOptionPane.showMessageDialog(dialog, "All fields are required.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            try {
                double price = Double.parseDouble(priceText);
                int stock = Integer.parseInt(stockText);

                if (product == null) {
                    try (PreparedStatement stmt = connection.prepareStatement(
                            "INSERT INTO stallburger (name, description, price, stock) VALUES (?, ?, ?, ?)")) {
                        stmt.setString(1, name);
                        stmt.setString(2, description);
                        stmt.setDouble(3, price);
                        stmt.setInt(4, stock);
                        stmt.executeUpdate();
                    }
                } else {
                    int id = (int) product[0];
                    try (PreparedStatement stmt = connection.prepareStatement(
                            "UPDATE stallburger SET name=?, description=?, price=?, stock=? WHERE id=?")) {
                        stmt.setString(1, name);
                        stmt.setString(2, description);
                        stmt.setDouble(3, price);
                        stmt.setInt(4, stock);
                        stmt.setInt(5, id);
                        stmt.executeUpdate();
                    }
                }

                fetchAndDisplayInventory();
                dialog.dispose();
            } catch (NumberFormatException | SQLException ex) {
                JOptionPane.showMessageDialog(dialog, "Error saving product: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                ex.printStackTrace();
            }
        });

        btnCancel.addActionListener(e -> dialog.dispose());

        dialog.setVisible(true);
    }

    private void openEditProductDialog() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a product to edit.", "Warning", JOptionPane.WARNING_MESSAGE);
            return;
        }

        Object[] product = {
            tableModel.getValueAt(selectedRow, 0),
            tableModel.getValueAt(selectedRow, 1),
            tableModel.getValueAt(selectedRow, 2),
            tableModel.getValueAt(selectedRow, 3),
            tableModel.getValueAt(selectedRow, 4)
        };

        openProductDialog("Edit Product", product);
    }

    private void deleteSelectedProduct() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a product to delete.", "Warning", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int id = (int) tableModel.getValueAt(selectedRow, 0);
        int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete this product?", "Confirm Delete", JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            try (PreparedStatement stmt = connection.prepareStatement("DELETE FROM stallburger WHERE id=?")) {
                stmt.setInt(1, id);
                stmt.executeUpdate();
                fetchAndDisplayInventory();
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, "Failed to delete the product: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                e.printStackTrace();
            }
        }
    }
}
