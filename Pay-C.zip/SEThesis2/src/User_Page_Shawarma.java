import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Image;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import javax.swing.*;
import javax.swing.border.Border;

public class User_Page_Shawarma extends JFrame {

    private JPanel contentPane;
    private JTextField searchField;
    private JPanel productPanel;
    private JButton btnShowAllProducts;  // Declare the "Show All Products" button

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                User_Page_Shawarma frame = new User_Page_Shawarma();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public User_Page_Shawarma() {
        setTitle("Stall Owner Dashboard");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 1000, 750);  // Adjusted window size for a professional layout
        contentPane = new JPanel();
        contentPane.setLayout(null);
        setContentPane(contentPane);

        // Header Section
        JLabel lblHeader = new JLabel("Stall Owner Dashboard");
        lblHeader.setForeground(new Color(44, 62, 80));
        lblHeader.setFont(new Font("Segoe UI", Font.BOLD, 26));
        lblHeader.setBounds(350, 10, 300, 40);  // Increased space for header
        contentPane.add(lblHeader);

        JLabel lblUserName = new JLabel("Stall: Zhiawarma");
        lblUserName.setForeground(new Color(44, 62, 80));
        lblUserName.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        lblUserName.setBounds(430, 55, 132, 25);  // Adjusted spacing
        contentPane.add(lblUserName);

        // Log Out Button
        JLabel lblLogOut = new JLabel("Log Out");
        lblLogOut.setForeground(new Color(52, 152, 219));
        lblLogOut.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblLogOut.setBounds(20, 20, 80, 20);
        lblLogOut.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        contentPane.add(lblLogOut);
        lblLogOut.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                LogIn_User.main(null);
                dispose();
            }
        });

        // Header Separator
        JSeparator headerSeparator = new JSeparator();
        headerSeparator.setBounds(10, 90, 960, 1);
        headerSeparator.setForeground(Color.GRAY);
        contentPane.add(headerSeparator);

        // Sidebar Section (with padding, rounded buttons, and improved spacing)
        JPanel sidebarPanel = new JPanel();
        sidebarPanel.setBackground(new Color(241, 250, 238));
        sidebarPanel.setBounds(10, 91, 230, 560);
        contentPane.add(sidebarPanel);
        sidebarPanel.setLayout(null);

        // Sidebar Buttons with Padding and Rounded Corners
        JButton btnManageProducts = new JButton("Manage Products");
        btnManageProducts.setBounds(20, 261, 200, 40);
        btnManageProducts.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        btnManageProducts.setBackground(new Color(52, 152, 219));
        btnManageProducts.setForeground(Color.WHITE);
        btnManageProducts.setFocusPainted(false);
        btnManageProducts.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY));
        sidebarPanel.add(btnManageProducts);

        JButton btnOrders = new JButton("View Orders");
        btnOrders.setBounds(20, 311, 200, 40);
        btnOrders.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        btnOrders.setBackground(new Color(52, 152, 219));
        btnOrders.setForeground(Color.WHITE);
        btnOrders.setFocusPainted(false);
        btnOrders.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY));
        sidebarPanel.add(btnOrders);

        JButton btnInventory = new JButton("View Inventory");
        btnInventory.setBounds(20, 361, 200, 40);
        btnInventory.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        btnInventory.setBackground(new Color(52, 152, 219));
        btnInventory.setForeground(Color.WHITE);
        btnInventory.setFocusPainted(false);
        btnInventory.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY));
        sidebarPanel.add(btnInventory);

        // Load the image for the placeholder (make sure the path is correct)
        ImageIcon originalIcon = new ImageIcon("C:\\Users\\Carl James Macapanas\\Desktop\\Pictures\\stalls\\products (3).jpg"); // Provide the image path here

        // Resize the image to fit the bounds of the JLabel
        Image scaledImage = originalIcon.getImage().getScaledInstance(210, 183, Image.SCALE_SMOOTH); // Adjust to JLabel size
        ImageIcon scaledIcon = new ImageIcon(scaledImage);

        JLabel lblPicture = new JLabel(scaledIcon);
        lblPicture.setBounds(10, 45, 210, 183);  // x, y, width, height
        lblPicture.setOpaque(true);  // Make it opaque so we can see the background color
        lblPicture.setHorizontalAlignment(SwingConstants.CENTER);
        lblPicture.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY));  // Border around the label
        sidebarPanel.add(lblPicture);


        // Search Section
        JLabel lblSearch = new JLabel("Search Products:");
        lblSearch.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblSearch.setBounds(260, 100, 120, 30);
        contentPane.add(lblSearch);

        searchField = new JTextField();
        searchField.setBounds(380, 100, 200, 30);
        contentPane.add(searchField);

        JButton btnSearch = new JButton("Search");
        btnSearch.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        btnSearch.setBounds(600, 100, 100, 30);
        contentPane.add(btnSearch);

        // Show All Products Button
        btnShowAllProducts = new JButton("Show All Products");
        btnShowAllProducts.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        btnShowAllProducts.setBounds(710, 100, 150, 30);  // Added button for showing all products
        contentPane.add(btnShowAllProducts);

        // Search Separator
        JSeparator searchSeparator = new JSeparator();
        searchSeparator.setBounds(260, 140, 640, 1);
        searchSeparator.setForeground(Color.GRAY);
        contentPane.add(searchSeparator);

        // Scrollable panel to hold product rows
        JScrollPane scrollPane = new JScrollPane();
        scrollPane.setBounds(260, 160, 680, 510);  // Adjusting size for better space distribution
        contentPane.add(scrollPane);

        productPanel = new JPanel();
        productPanel.setLayout(new BoxLayout(productPanel, BoxLayout.Y_AXIS));  // Using BoxLayout for vertical layout
        scrollPane.setViewportView(productPanel);

        // Fetch and display products from the database
        List<Product> products = getStallsDataFromDatabase();
        for (int i = 0; i < Math.min(products.size(), 8); i++) {  // Limit to 8 products
            Product product = products.get(i);
            createProductRow(product, productPanel);
        }

        // Action Listeners (with more informative messages)
        btnSearch.addActionListener(e -> {
            String keyword = searchField.getText().trim();
            if (keyword.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please enter a search term.", "Empty Search", JOptionPane.WARNING_MESSAGE);
                // Reset the product list to show all products
                List<Product> allProducts = getStallsDataFromDatabase();
                productPanel.removeAll();
                for (Product product : allProducts) {
                    createProductRow(product, productPanel);
                }
                productPanel.revalidate();
                productPanel.repaint();
                return;
            }

            // Search query
            List<Product> filteredProducts = searchProducts(keyword);
            productPanel.removeAll();  // Clear existing product rows
            if (filteredProducts.isEmpty()) {
                JOptionPane.showMessageDialog(this, "No products match your search.", "Search Results", JOptionPane.INFORMATION_MESSAGE);
            } else {
                for (Product product : filteredProducts) {
                    createProductRow(product, productPanel);  // Add the filtered products
                }
            }
            productPanel.revalidate();
            productPanel.repaint();
        });

        // Action listener for Show All Products button
        btnShowAllProducts.addActionListener(e -> {
            List<Product> allProducts = getStallsDataFromDatabase();
            productPanel.removeAll();
            for (Product product : allProducts) {
                createProductRow(product, productPanel);
            }
            productPanel.revalidate();
            productPanel.repaint();
        });

        btnManageProducts.addActionListener(e -> {
            User_Page_Burger_ManageProduct.main(null);
            dispose();
        });

        btnOrders.addActionListener(e -> {
            User_Page_Burger_ViewOrders.main(null);
            dispose();
        });

        btnInventory.addActionListener(e -> {
            User_Page_Burger_Inventory.main(null);
            dispose();
        });
    }

    private void createProductRow(Product product, JPanel productPanel) {
        JPanel productRow = new JPanel();
        productRow.setLayout(null);
        productRow.setBackground(new Color(247, 249, 251));  // Subtle background color for each product row
        productRow.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY, 1));  // Light border for separation
        productRow.setPreferredSize(new java.awt.Dimension(640, 110));  // Increase the height for spacing
        productPanel.add(productRow);

        JLabel lblProductName = new JLabel(product.getName());
        lblProductName.setFont(new Font("Segoe UI", Font.BOLD, 16));  // Larger font for name
        lblProductName.setForeground(new Color(52, 152, 219));
        lblProductName.setBounds(10, 10, 200, 30);
        productRow.add(lblProductName);

        // Product Image (adjusted size with border and centered)
        ImageIcon productImage = new ImageIcon(product.getImageFilePath());  // Create image icon from file path
        Image image = productImage.getImage();
        Image scaledImage = image.getScaledInstance(80, 80, Image.SCALE_SMOOTH);
        ImageIcon scaledProductImage = new ImageIcon(scaledImage);
        JLabel lblProductImage = new JLabel(scaledProductImage);
        lblProductImage.setBounds(10, 45, 80, 80);  // Adjusted size for image
        lblProductImage.setHorizontalAlignment(SwingConstants.CENTER);
        productRow.add(lblProductImage);

        JLabel lblDescription = new JLabel("<html><div style='width: 230px;'>" + product.getDescription() + "</div></html>");
        lblDescription.setFont(new Font("Segoe UI", Font.PLAIN, 14));  // Adjusted font for description
        lblDescription.setBounds(100, 45, 230, 60);  // Adjusted bounds for better spacing
        productRow.add(lblDescription);

        JButton btnDetails = new JButton("View Details");
        btnDetails.setBounds(330, 35, 130, 35);  // Increased size for button
        btnDetails.setBackground(new Color(52, 152, 219));
        btnDetails.setForeground(Color.WHITE);
        btnDetails.setFont(new Font("Segoe UI", Font.PLAIN, 14));  // Larger font for button
        productRow.add(btnDetails);

        btnDetails.addActionListener(e -> {
            String detailsMessage = "<html>"
                    + "<strong>Product Name:</strong> " + product.getName() + "<br><br>"
                    + "<strong>Description:</strong> " + product.getDescription() + "<br><br>"
                    + "<strong>Ingredients:</strong> " + product.getIngredients() + "<br><br>"
                    + "<strong>Price:</strong> $" + product.getPrice() + "<br>"
                    + "</html>";

            JLabel label = new JLabel(detailsMessage);
            JOptionPane.showMessageDialog(this, label, "Product Details", JOptionPane.INFORMATION_MESSAGE);
        });

        JSeparator productSeparator = new JSeparator();
        productSeparator.setBounds(0, 100, 640, 1);
        productRow.add(productSeparator);

        productPanel.add(Box.createVerticalStrut(10));  // Adds vertical space between product rows
    }

    private List<Product> getStallsDataFromDatabase() {
        List<Product> products = new ArrayList<>();
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/sethesis", "root", "");
             PreparedStatement stmt = conn.prepareStatement("SELECT name, description, image_file_path, ingredients, price FROM stallshawarma");
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                String name = rs.getString("name");
                String description = rs.getString("description");
                String imageFilePath = rs.getString("image_file_path");
                String ingredients = rs.getString("ingredients");
                double price = rs.getDouble("price");

                products.add(new Product(name, description, imageFilePath, ingredients, price));
            }

        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "An error occurred while fetching the data: " + e.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }

        return products;
    }

    private List<Product> searchProducts(String keyword) {
        List<Product> filteredProducts = new ArrayList<>();
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/sethesis", "root", "");
             PreparedStatement stmt = conn.prepareStatement(
                     "SELECT name, description, image_file_path, ingredients, price FROM stallshawarma " +
                             "WHERE LOWER(name) LIKE ? OR LOWER(description) LIKE ?")) {
            stmt.setString(1, "%" + keyword.toLowerCase() + "%");
            stmt.setString(2, "%" + keyword.toLowerCase() + "%");

            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                String name = rs.getString("name");
                String description = rs.getString("description");
                String imageFilePath = rs.getString("image_file_path");
                String ingredients = rs.getString("ingredients");
                double price = rs.getDouble("price");

                filteredProducts.add(new Product(name, description, imageFilePath, ingredients, price));
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Search operation failed: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
        return filteredProducts;
    }

    // Product Class
    static class Product {
        private String name;
        private String description;
        private String imageFilePath;
        private String ingredients;
        private double price;

        // Constructor
        public Product(String name, String description, String imageFilePath, String ingredients, double price) {
            this.name = name;
            this.description = description;
            this.imageFilePath = imageFilePath;
            this.ingredients = ingredients;
            this.price = price;
        }

        // Getter methods
        public String getName() {
            return name;
        }

        public String getDescription() {
            return description;
        }

        public String getImageFilePath() {
            return imageFilePath;
        }

        public String getIngredients() {
            return ingredients;
        }

        public double getPrice() {
            return price;
        }
    }
}
