import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableColumn;
import javax.swing.table.TableCellRenderer;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.*;

public class User_Page_Tindahan_ViewOrders extends JFrame {

    private JPanel contentPane;
    private JTable table;
    private DefaultTableModel tableModel;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                User_Page_Tindahan_ViewOrders frame = new User_Page_Tindahan_ViewOrders();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(null, "An error occurred while launching the application.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
    }

    /**
     * Create the frame.
     */
    public User_Page_Tindahan_ViewOrders() {
        setTitle("Tindahan - View Orders");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 900, 600);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(10, 10, 10, 10));
        contentPane.setLayout(new BorderLayout(10, 10));
        contentPane.setBackground(Color.WHITE);
        setContentPane(contentPane);

        // Header Panel
        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(new Color(41, 128, 185));
        headerPanel.setPreferredSize(new Dimension(0, 70));
        headerPanel.setLayout(null);

        JLabel lblHeader = new JLabel("Customer Orders");
        lblHeader.setBounds(0, 0, 866, 70);
        lblHeader.setFont(new Font("Segoe UI", Font.BOLD, 30));
        lblHeader.setForeground(Color.WHITE);
        lblHeader.setHorizontalAlignment(SwingConstants.CENTER);
        headerPanel.add(lblHeader);
        contentPane.add(headerPanel, BorderLayout.NORTH);

        // Table Panel
        JPanel tablePanel = new JPanel();
        tablePanel.setBackground(Color.WHITE);
        contentPane.add(tablePanel, BorderLayout.CENTER);

        // Table with custom header styling
        // Update table model to include Payment Method
        tableModel = new DefaultTableModel(new Object[]{"Order ID", "Customer Name", "Order Details", "Date & Time", "Payment Method"}, 0);
        table = new JTable(tableModel) {
            // Make cells non-editable
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        table.setFillsViewportHeight(true);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        table.setRowHeight(30);

        // Set custom table header
        JTableHeader tableHeader = table.getTableHeader();
        tableHeader.setFont(new Font("Segoe UI", Font.BOLD, 14));
        tableHeader.setBackground(new Color(52, 152, 219));
        tableHeader.setForeground(Color.WHITE);
        tablePanel.setLayout(null);

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(0, 0, 866, 403);
        scrollPane.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200), 1));
        tablePanel.add(scrollPane);

        // Automatically adjust column widths
        adjustColumnWidths();

        // Footer Panel
        JPanel footerPanel = new JPanel(new BorderLayout());
        footerPanel.setBackground(Color.WHITE);
        footerPanel.setPreferredSize(new Dimension(0, 50));
        
        // Add Back Button
        JButton btnBack = new JButton("Back");
        btnBack.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnBack.setBackground(new Color(41, 128, 185));
        btnBack.setForeground(Color.WHITE);
        btnBack.setFocusPainted(false);
        btnBack.setBorder(BorderFactory.createEmptyBorder(5, 15, 5, 15));
        btnBack.addActionListener(e -> {
            dispose(); // Close the current frame
            User_Page_Burger mainPage = new User_Page_Burger(); // Replace with the actual main page class
            mainPage.setVisible(true); // Open the main page
        });

        // Add Back Button to Footer Panel
        footerPanel.add(btnBack, BorderLayout.WEST);

        JButton btnRefresh = new JButton("Refresh");
        btnRefresh.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnRefresh.setBackground(new Color(46, 204, 113));
        btnRefresh.setForeground(Color.WHITE);
        btnRefresh.setFocusPainted(false);
        btnRefresh.setBorder(BorderFactory.createEmptyBorder(5, 15, 5, 15));
        btnRefresh.addActionListener(e -> fetchAndDisplayOrders());

        footerPanel.add(btnRefresh, BorderLayout.EAST);
        contentPane.add(footerPanel, BorderLayout.SOUTH);

        // Fetch and display orders initially
        fetchAndDisplayOrders();
    }

    private void adjustColumnWidths() {
        // Adjust column widths based on content
        for (int col = 0; col < table.getColumnCount(); col++) {
            TableColumn column = table.getColumnModel().getColumn(col);
            int preferredWidth = 100; // Minimum width
            for (int row = 0; row < table.getRowCount(); row++) {
                TableCellRenderer cellRenderer = table.getCellRenderer(row, col);
                Component component = table.prepareRenderer(cellRenderer, row, col);
                preferredWidth = Math.max(component.getPreferredSize().width + 10, preferredWidth);
            }
            column.setPreferredWidth(preferredWidth);
        }
    }

    private void fetchAndDisplayOrders() {
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/sethesis", "root", "");
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM orders_tindahan ORDER BY order_date DESC")) {

            // Clear table before adding new rows
            tableModel.setRowCount(0);

            while (rs.next()) {
                Object[] row = {
                        rs.getInt("id"),
                        rs.getString("customer_name"),
                        rs.getString("order_details"),
                        rs.getTimestamp("order_date"),
                        rs.getString("payment_method") // Fetch payment method
                };
                tableModel.addRow(row);
            }

            // Adjust column widths after adding rows
            adjustColumnWidths();

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Failed to fetch orders. Check your database connection.", "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }

}
