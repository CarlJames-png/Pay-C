import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.sql.*;
import java.io.File;

public class User_Page_Turon_ManageProduct extends JFrame {

    private JPanel contentPane;
    private JTable table;
    private DefaultTableModel tableModel;

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                User_Page_Turon_ManageProduct frame = new User_Page_Turon_ManageProduct();
                frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(null, "An error occurred while launching the application.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
    }

    public User_Page_Turon_ManageProduct() {
        setTitle("Manage Products - Shawarma");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 900, 600);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(10, 10, 10, 10));
        contentPane.setLayout(new BorderLayout(10, 10));
        contentPane.setBackground(new Color(245, 245, 245));
        setContentPane(contentPane);

        // Header Panel
        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(new Color(52, 152, 219));
        headerPanel.setLayout(new BorderLayout());
        headerPanel.setPreferredSize(new Dimension(0, 60));

        JLabel lblHeader = new JLabel("Manage Products");
        lblHeader.setFont(new Font("Segoe UI", Font.BOLD, 28));
        lblHeader.setForeground(Color.WHITE);
        lblHeader.setHorizontalAlignment(SwingConstants.CENTER);
        headerPanel.add(lblHeader, BorderLayout.CENTER);
        contentPane.add(headerPanel, BorderLayout.NORTH);

        // Table Panel
        JPanel tablePanel = new JPanel(new BorderLayout());
        tablePanel.setBackground(new Color(245, 245, 245));
        contentPane.add(tablePanel, BorderLayout.CENTER);

        // Table with custom header styling
        tableModel = new DefaultTableModel(new Object[]{"ID", "Name", "Ingredients", "Price", "Description"}, 0);
        table = new JTable(tableModel);
        table.setFillsViewportHeight(true);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        table.setRowHeight(30);

        // Set custom table header
        JTableHeader tableHeader = table.getTableHeader();
        tableHeader.setFont(new Font("Segoe UI", Font.BOLD, 14));
        tableHeader.setBackground(new Color(52, 152, 219));
        tableHeader.setForeground(Color.WHITE);

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createEmptyBorder());
        tablePanel.add(scrollPane, BorderLayout.CENTER);

        // Fetch and display products
        fetchAndDisplayProducts();

        // Buttons Panel
        JPanel buttonsPanel = new JPanel();
        buttonsPanel.setLayout(new FlowLayout(FlowLayout.RIGHT, 10, 10));
        buttonsPanel.setBackground(new Color(245, 245, 245));
        contentPane.add(buttonsPanel, BorderLayout.SOUTH);

        // Add Product Button
        JButton btnAdd = createButton("Add Product", new Color(46, 204, 113), Color.WHITE);
        buttonsPanel.add(btnAdd);

        // Edit Product Button
        JButton btnEdit = createButton("Edit Product", new Color(241, 196, 15), Color.WHITE);
        buttonsPanel.add(btnEdit);

        // Delete Product Button
        JButton btnDelete = createButton("Delete Product", new Color(231, 76, 60), Color.WHITE);
        buttonsPanel.add(btnDelete);

        // Add Back Button
        JButton btnBack = createButton("Back", new Color(52, 152, 219), Color.WHITE);
        buttonsPanel.add(btnBack);

        // Action for Back Button
        btnBack.addActionListener(e -> {
            dispose(); // Close the current frame
            User_Page_Turon mainPage = new User_Page_Turon(); // Replace with your main page class name
            mainPage.setVisible(true); // Show the main page
        });
        
        // Button Actions
        btnAdd.addActionListener(e -> openAddProductDialog());
        btnEdit.addActionListener(e -> openEditProductDialog());
        btnDelete.addActionListener(e -> deleteSelectedProduct());
    }

    private JButton createButton(String text, Color bgColor, Color fgColor) {
        JButton button = new JButton(text);
        button.setFont(new Font("Segoe UI", Font.BOLD, 14));
        button.setBackground(bgColor);
        button.setForeground(fgColor);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createLineBorder(bgColor.darker()));
        button.setPreferredSize(new Dimension(140, 40));
        return button;
    }

    private void fetchAndDisplayProducts() {
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/sethesis", "root", "");
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM stallturon")) {

            // Clear table before adding new rows
            tableModel.setRowCount(0);

            while (rs.next()) {
                Object[] row = {
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("ingredients"),
                        rs.getDouble("price"),
                        rs.getString("description")
                };
                tableModel.addRow(row);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Failed to fetch products. Check your database connection.", "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }

    private void openAddProductDialog() {
        createProductDialog("Add Product", null);
    }

    private void openEditProductDialog() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a product to edit.", "Warning", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int id = (int) table.getValueAt(selectedRow, 0);
        String name = (String) table.getValueAt(selectedRow, 1);
        String ingredients = (String) table.getValueAt(selectedRow, 2);
        double price = (double) table.getValueAt(selectedRow, 3);
        String description = (String) table.getValueAt(selectedRow, 4);

        Product product = new Product(id, name, ingredients, price, description, null);  // No image file path here
        createProductDialog("Edit Product", product);
    }

    private void createProductDialog(String title, Product product) {
        JDialog dialog = new JDialog(this, title, true);
        dialog.setSize(400, 500);
        dialog.setLayout(new BorderLayout(10, 10));
        dialog.setLocationRelativeTo(this);

        // Input Panel
        JPanel inputPanel = new JPanel(new GridLayout(6, 2, 10, 10));
        inputPanel.setBorder(new EmptyBorder(10, 10, 10, 10));

        JLabel lblName = new JLabel("Name:");
        JTextField txtName = new JTextField(product != null ? product.name : "");

        JLabel lblIngredients = new JLabel("Ingredients:");
        JTextField txtIngredients = new JTextField(product != null ? product.ingredients : "");

        JLabel lblPrice = new JLabel("Price:");
        JTextField txtPrice = new JTextField(product != null ? String.valueOf(product.price) : "");

        JLabel lblDescription = new JLabel("Description:");
        JTextArea txtDescription = new JTextArea(product != null ? product.description : "");
        JScrollPane descriptionScrollPane = new JScrollPane(txtDescription);

        JLabel lblImage = new JLabel("Image:");
        JButton btnChooseImage = new JButton("Choose Image");
        JLabel lblImagePath = new JLabel("(No image selected)");

        // Handle Image Selection
        final String[] imageFilePath = new String[1]; 
        btnChooseImage.addActionListener(e -> {
            JFileChooser fileChooser = new JFileChooser();
            int result = fileChooser.showOpenDialog(this);
            if (result == JFileChooser.APPROVE_OPTION) {
                File selectedFile = fileChooser.getSelectedFile();
                imageFilePath[0] = selectedFile.getAbsolutePath();
                lblImagePath.setText(selectedFile.getName());
            }
        });

        inputPanel.add(lblName);
        inputPanel.add(txtName);
        inputPanel.add(lblIngredients);
        inputPanel.add(txtIngredients);
        inputPanel.add(lblPrice);
        inputPanel.add(txtPrice);
        inputPanel.add(lblDescription);
        inputPanel.add(descriptionScrollPane);
        inputPanel.add(lblImage);
        inputPanel.add(btnChooseImage);

        dialog.add(inputPanel, BorderLayout.CENTER);

        // Button Panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton btnSave = createButton("Save", new Color(46, 204, 113), Color.WHITE);
        JButton btnCancel = createButton("Cancel", new Color(231, 76, 60), Color.WHITE);

        buttonPanel.add(btnSave);
        buttonPanel.add(btnCancel);
        dialog.add(buttonPanel, BorderLayout.SOUTH);

        btnSave.addActionListener(e -> {
            String name = txtName.getText().trim();
            String ingredients = txtIngredients.getText().trim();
            String priceText = txtPrice.getText().trim();
            String description = txtDescription.getText().trim();

            if (name.isEmpty() || ingredients.isEmpty() || priceText.isEmpty() || description.isEmpty()) {
                JOptionPane.showMessageDialog(dialog, "All fields are required.", "Validation Error", JOptionPane.WARNING_MESSAGE);
                return;
            }

            try {
                double price = Double.parseDouble(priceText);

                if (product == null) {
                    addProductToDatabase(name, ingredients, price, description, imageFilePath[0]);
                } else {
                    updateProductInDatabase(product.id, name, ingredients, price, description, imageFilePath[0]);
                }

                dialog.dispose();
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(dialog, "Price must be a valid number.", "Validation Error", JOptionPane.WARNING_MESSAGE);
            }
        });

        btnCancel.addActionListener(e -> dialog.dispose());
        dialog.setVisible(true);
    }

    private void addProductToDatabase(String name, String ingredients, double price, String description, String imageFilePath) {
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/sethesis", "root", "");
             PreparedStatement stmt = conn.prepareStatement("INSERT INTO stallturon (name, ingredients, price, description, image_file_path) VALUES (?, ?, ?, ?, ?)")) {

            stmt.setString(1, name);
            stmt.setString(2, ingredients);
            stmt.setDouble(3, price);
            stmt.setString(4, description);
            stmt.setString(5, imageFilePath);  // Storing the image path

            stmt.executeUpdate();

            JOptionPane.showMessageDialog(this, "Product added successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
            fetchAndDisplayProducts();

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Failed to add the product.", "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }

    private void updateProductInDatabase(int id, String name, String ingredients, double price, String description, String imageFilePath) {
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/sethesis", "root", "");
             PreparedStatement stmt = conn.prepareStatement("UPDATE stallturon SET name = ?, ingredients = ?, price = ?, description = ?, image_file_path = ? WHERE id = ?")) {

            stmt.setString(1, name);
            stmt.setString(2, ingredients);
            stmt.setDouble(3, price);
            stmt.setString(4, description);
            stmt.setString(5, imageFilePath);  // Updating the image path
            stmt.setInt(6, id);

            stmt.executeUpdate();

            JOptionPane.showMessageDialog(this, "Product updated successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
            fetchAndDisplayProducts();

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Failed to update the product.", "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }

    private void deleteSelectedProduct() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a product to delete.", "Warning", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String name = (String) table.getValueAt(selectedRow, 1);
        int id = (int) table.getValueAt(selectedRow, 0);

        int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete \"" + name + "\"?", "Confirm Delete", JOptionPane.YES_NO_OPTION);
        if (confirm != JOptionPane.YES_OPTION) return;

        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/sethesis", "root", "");
             PreparedStatement stmt = conn.prepareStatement("DELETE FROM stallturon WHERE id = ?")) {

            stmt.setInt(1, id);
            stmt.executeUpdate();

            JOptionPane.showMessageDialog(this, "Product deleted successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
            fetchAndDisplayProducts();

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Failed to delete the product.", "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }

    // Product Class
    private static class Product {
        int id;
        String name;
        String ingredients;
        double price;
        String description;
        String imageFilePath;

        Product(int id, String name, String ingredients, double price, String description, String imageFilePath) {
            this.id = id;
            this.name = name;
            this.ingredients = ingredients;
            this.price = price;
            this.description = description;
            this.imageFilePath = imageFilePath;
        }
    }
}
